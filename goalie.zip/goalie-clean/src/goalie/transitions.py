"""State-machine registry + transition helper for goalie verbs."""
from __future__ import annotations

from pathlib import Path

from .store import Node, Status, find_by_id, index_lock, set_status

LEGAL_TRANSITIONS: dict[tuple[str, Status], Status] = {
    ("plan",    Status.unplanned):     Status.pending,
    ("split",   Status.unplanned):     Status.pending,
    ("split",   Status.pending):       Status.pending,
    ("split",   Status.rejected):      Status.pending,
    ("done",    Status.pending):       Status.needs_review,
    ("done",    Status.rejected):      Status.needs_review,
    ("approve", Status.needs_review):  Status.done,
    ("reject",  Status.needs_review):  Status.rejected,
}

REQUIRED_FILES: dict[str, tuple[str, ...]] = {
    "plan":    ("task.md", "verify.md"),
    "split":   ("verify.md",),
    "done":    (),
    "approve": (),
    "reject":  (),
}


def transition_under_lock(cp: Path, node_id: str, verb: str) -> tuple[Node, Status]:
    """Acquire lock, validate transition, flip status. Return (node, new_status).

    Raises ValueError on illegal transition.
    """
    with index_lock(cp):
        node = find_by_id(cp, node_id)
        to_status = LEGAL_TRANSITIONS.get((verb, node.status))
        if to_status is None:
            froms = [s.value for (v, s) in LEGAL_TRANSITIONS if v == verb]
            expected = " or ".join(f"`{s}`" for s in froms) if froms else "no valid source status"
            raise ValueError(
                f"node `{node.short_id}` is `{node.status.value}`; "
                f"`{verb}` requires status {expected}."
            )
        set_status(node, to_status)
        return node, to_status
