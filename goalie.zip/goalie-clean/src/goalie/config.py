"""Goalie config — `.goalie/config.json`.

Maps roles to status watchlists and points at the target repo (which may be
the same dir, a sibling clone, or a worktree).
"""
from __future__ import annotations

import json
import os
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

CONFIG_FILENAME = "config.json"
_LEGACY_FILENAME = "config.yaml"

DEFAULT_ROLES: dict[str, dict[str, list[str]]] = {
    "planner":  {"watches": ["unplanned", "rejected"]},
    "solver":    {"watches": ["pending", "rejected"]},
    "reviewer": {"watches": ["needs_review"]},
}


def _has_config(p: Path) -> bool:
    return (p / CONFIG_FILENAME).is_file() or (p / _LEGACY_FILENAME).is_file()


def _migrate_yaml(yaml_path: Path) -> dict:
    try:
        import yaml as _yaml  # type: ignore[import]
        data = _yaml.safe_load(yaml_path.read_text()) or {}
    except ImportError:
        raise FileNotFoundError(
            f"Found legacy {yaml_path} but PyYAML is not available for migration.\n"
            "Please re-run `goalie init <goal>` to create config.json."
        )
    return data


@dataclass
class Config:
    target_repo: Path
    roles: dict[str, dict[str, list[str]]] = field(default_factory=lambda: dict(DEFAULT_ROLES))
    control_plane_dir: Path = field(default_factory=Path)
    vendors: list[str] = field(default_factory=list)

    @classmethod
    def load(cls, control_plane_dir: Path) -> "Config":
        json_path = control_plane_dir / CONFIG_FILENAME
        yaml_path = control_plane_dir / _LEGACY_FILENAME

        if json_path.exists():
            data = json.loads(json_path.read_text(encoding="utf-8")) or {}
        elif yaml_path.exists():
            print(f"goalie: migrating {yaml_path.name} → {CONFIG_FILENAME}", file=sys.stderr)
            data = _migrate_yaml(yaml_path)
            json_path.write_text(json.dumps(data, indent=2), encoding="utf-8")
            yaml_path.unlink()
        else:
            raise FileNotFoundError(
                f"Missing {json_path}. Run `goalie init` first."
            )

        target = data.get("target_repo", ".")
        target_path = (
            (control_plane_dir.parent / target).resolve()
            if not Path(target).is_absolute()
            else Path(target).resolve()
        )
        if not target_path.exists():
            raise FileNotFoundError(
                f"target_repo '{target}' resolved to {target_path} (does not exist)"
            )
        roles = data.get("roles") or dict(DEFAULT_ROLES)
        vendors = data.get("vendors") or []
        return cls(
            target_repo=target_path,
            roles=roles,
            control_plane_dir=control_plane_dir,
            vendors=vendors,
        )

    def save(self) -> None:
        cfg_path = self.control_plane_dir / CONFIG_FILENAME
        out = {
            "target_repo": str(self._target_relative()),
            "roles": self.roles,
            "vendors": self.vendors,
        }
        cfg_path.parent.mkdir(parents=True, exist_ok=True)
        cfg_path.write_text(json.dumps(out, indent=2), encoding="utf-8")

    def _target_relative(self) -> Path:
        try:
            return (
                Path(".")
                if self.target_repo == self.control_plane_dir.parent.resolve()
                else Path(*self.target_repo.relative_to(self.control_plane_dir.parent.resolve()).parts)
            )
        except ValueError:
            return self.target_repo

    def watchlist(self, role: str) -> list[str]:
        if role not in self.roles:
            raise KeyError(f"Unknown role '{role}'. Configured roles: {sorted(self.roles)}")
        return list(self.roles[role].get("watches", []))


def resolve_control_plane(cwd: Path, *, override: Optional[str] = None) -> Path:
    """Resolve the control-plane path with documented precedence:
    1. override argument (from --cp flag)
    2. GOALIE_CP environment variable
    3. Walk up from cwd until a .goalie/config.json (or config.yaml) is found
    4. Loud error with both remediation paths
    """
    if override is not None:
        p = Path(override).resolve()
        if not _has_config(p):
            raise FileNotFoundError(
                f"--cp {override!r}: no config.json found at {p}"
            )
        return p

    env_val = os.environ.get("GOALIE_CP")
    if env_val:
        p = Path(env_val).resolve()
        if not _has_config(p):
            raise FileNotFoundError(
                f"GOALIE_CP={env_val!r}: no config.json found at {p}"
            )
        return p

    p = cwd.resolve()
    for anc in [p, *p.parents]:
        cand = anc / ".goalie"
        if _has_config(cand):
            return cand
        if cand.is_dir() and any(cand.iterdir()):
            return cand

    raise FileNotFoundError(
        "no control plane found.\n"
        "  - set GOALIE_CP=<path/to/control-plane> in this shell, or\n"
        "  - run goalie from inside (or a descendant of) a directory that\n"
        "    contains .goalie/."
    )
