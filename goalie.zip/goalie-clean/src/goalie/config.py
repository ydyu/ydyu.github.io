"""Goalie config — `.goalie/config.yaml`.

Maps roles to status watchlists and points at the target repo (which may be
the same dir, a sibling clone, or a worktree).
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import yaml

CONFIG_FILENAME = "config.yaml"
DEFAULT_ROLES: dict[str, dict[str, list[str]]] = {
    "planner":  {"watches": ["unplanned", "rejected"]},
    "solver":    {"watches": ["pending", "rejected"]},
    "reviewer": {"watches": ["needs_review"]},
}


@dataclass
class Config:
    target_repo: Path
    roles: dict[str, dict[str, list[str]]] = field(default_factory=lambda: dict(DEFAULT_ROLES))
    control_plane_dir: Path = field(default_factory=Path)
    vendors: list[str] = field(default_factory=list)

    @classmethod
    def load(cls, control_plane_dir: Path) -> "Config":
        cfg_path = control_plane_dir / CONFIG_FILENAME
        if not cfg_path.exists():
            raise FileNotFoundError(f"Missing {cfg_path}. Run `goalie init` first.")
        data = yaml.safe_load(cfg_path.read_text()) or {}
        target = data.get("target_repo", ".")
        target_path = (control_plane_dir.parent / target).resolve() if not Path(target).is_absolute() else Path(target).resolve()
        if not target_path.exists():
            raise FileNotFoundError(f"target_repo '{target}' resolved to {target_path} (does not exist)")
        roles = data.get("roles") or dict(DEFAULT_ROLES)
        vendors = data.get("vendors") or []
        return cls(target_repo=target_path, roles=roles, control_plane_dir=control_plane_dir, vendors=vendors)

    def save(self) -> None:
        cfg_path = self.control_plane_dir / CONFIG_FILENAME
        # store target_repo as the original literal string the user gave us, if possible
        # (the resolved Path is stored; on load we re-resolve)
        out = {
            "target_repo": str(self._target_relative()),
            "roles": self.roles,
            "vendors": self.vendors,
        }
        cfg_path.parent.mkdir(parents=True, exist_ok=True)
        cfg_path.write_text(yaml.safe_dump(out, sort_keys=False))

    def _target_relative(self) -> Path:
        try:
            return Path(".") if self.target_repo == self.control_plane_dir.parent.resolve() else \
                Path(*self.target_repo.relative_to(self.control_plane_dir.parent.resolve()).parts)
        except ValueError:
            return self.target_repo

    def watchlist(self, role: str) -> list[str]:
        if role not in self.roles:
            raise KeyError(f"Unknown role '{role}'. Configured roles: {sorted(self.roles)}")
        return list(self.roles[role].get("watches", []))


def resolve_control_plane(cwd: Path, *, override: Optional[str] = None) -> Path:
    """Resolve the control-plane path with documented precedence:
    1. override argument (from --cp flag)
    2. GOALIE_CP environment variable
    3. Walk up from cwd until a .goalie/config.yaml is found
    4. Loud error with both remediation paths
    """
    if override is not None:
        p = Path(override).resolve()
        if not (p / CONFIG_FILENAME).is_file():
            raise FileNotFoundError(
                f"--cp {override!r}: no config.yaml found at {p}"
            )
        return p

    env_val = os.environ.get("GOALIE_CP")
    if env_val:
        p = Path(env_val).resolve()
        if not (p / CONFIG_FILENAME).is_file():
            raise FileNotFoundError(
                f"GOALIE_CP={env_val!r}: no config.yaml found at {p}"
            )
        return p

    p = cwd.resolve()
    for anc in [p, *p.parents]:
        cand = anc / ".goalie"
        if (cand / CONFIG_FILENAME).is_file():
            return cand
        # legacy: a `.goalie/` with no config.yaml — still valid as control plane root
        if cand.is_dir() and any(cand.iterdir()):
            return cand

    raise FileNotFoundError(
        "no control plane found.\n"
        "  - set GOALIE_CP=<path/to/control-plane> in this shell, or\n"
        "  - run goalie from inside (or a descendant of) a directory that\n"
        "    contains .goalie/."
    )
