"""File-backed state for goalie.

Authority: frontmatter `id` / `parent` / `status` are the source of truth for
the goal tree. Directory names are slugs and may be renamed by humans.

Layout under `.goalie/` (control-plane dir):
  config.json
  index.lock                    # exclusively locked during state mutations
  nodes/<id>/
    goal.md                     # frontmatter: id, parent, status, title, created
    task.md                     # written by planner (optional)
    verify.md                   # written by planner (optional)
    attempts.md                 # appended on rejected
"""
from __future__ import annotations

import contextlib
import re
import sys
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Iterable, Iterator, Optional

from ._compat import mint_ulid, fm_load, fm_dump

GOALIE_DIR = ".goalie"
NODES_DIRNAME = "nodes"
LOCK_FILENAME = "index.lock"
LOCK_TIMEOUT_SEC = 2.0


class Status(str, Enum):
    unplanned = "unplanned"
    pending = "pending"
    needs_review = "needs_review"
    rejected = "rejected"
    done = "done"


TERMINAL = {Status.done}


@dataclass
class Node:
    id: str
    parent: Optional[str]
    status: Status
    title: str
    created: str
    dir: Path
    body: str = ""
    prior_attempts: int = 0
    verified_sha: Optional[str] = None
    children: list["Node"] = field(default_factory=list)

    @property
    def goal_path(self) -> Path: return self.dir / "goal.md"
    @property
    def task_path(self) -> Path: return self.dir / "task.md"
    @property
    def verify_path(self) -> Path: return self.dir / "verify.md"
    @property
    def attempts_path(self) -> Path: return self.dir / "attempts.md"

    @property
    def short_id(self) -> str:
        return self.id[-8:].lower()


# ---------- helpers ----------

def now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


_SLUG_RE = re.compile(r"[^a-z0-9]+")

def slugify(title: str) -> str:
    s = _SLUG_RE.sub("-", title.lower()).strip("-")
    return s[:48] or "node"


def unique_slug(parent: Path, title: str) -> str:
    base = slugify(title)
    if not (parent / base).exists():
        return base
    n = 2
    while (parent / f"{base}-{n}").exists():
        n += 1
    return f"{base}-{n}"


# ---------- locking ----------

try:
    import fcntl as _fcntl

    def _acquire_lock(fd: int) -> None:
        _fcntl.flock(fd, _fcntl.LOCK_EX | _fcntl.LOCK_NB)

    def _release_lock(fd: int) -> None:
        _fcntl.flock(fd, _fcntl.LOCK_UN)

except ImportError:
    import msvcrt as _msvcrt
    import os as _os

    def _acquire_lock(fd: int) -> None:  # type: ignore[misc]
        _os.lseek(fd, 0, 0)
        _msvcrt.locking(fd, _msvcrt.LK_NBLCK, 1)

    def _release_lock(fd: int) -> None:  # type: ignore[misc]
        _os.lseek(fd, 0, 0)
        _msvcrt.locking(fd, _msvcrt.LK_UNLCK, 1)


class LockContention(RuntimeError):
    """Raised when index.lock can't be acquired within LOCK_TIMEOUT_SEC."""


@contextlib.contextmanager
def index_lock(control_plane: Path) -> Iterator[None]:
    """Hold an exclusive lock on `.goalie/index.lock` for the duration of a
    state-mutating operation. Reads do not need this lock."""
    control_plane.mkdir(parents=True, exist_ok=True)
    lock_path = control_plane / LOCK_FILENAME
    lock_path.touch(exist_ok=True)
    import time
    deadline = time.monotonic() + LOCK_TIMEOUT_SEC
    f = lock_path.open("w")
    try:
        while True:
            try:
                _acquire_lock(f.fileno())
                break
            except (BlockingIOError, PermissionError, OSError):
                if time.monotonic() >= deadline:
                    raise LockContention(
                        f"Could not acquire {lock_path} within {LOCK_TIMEOUT_SEC}s. "
                        "Another goalie process is mutating state."
                    )
                time.sleep(0.05)
        yield
    finally:
        try:
            _release_lock(f.fileno())
        finally:
            f.close()


@contextlib.contextmanager
def locked_node(cp: Path, ident: str) -> Iterator[Node]:
    """Acquire index lock, resolve node, yield it. Lock released on exit."""
    with index_lock(cp):
        yield find_by_id(cp, ident)


# ---------- persistence ----------

def read_node(goal_md: Path) -> Node:
    meta, body = fm_load(goal_md.read_text(encoding="utf-8"))
    return Node(
        id=meta["id"],
        parent=(meta["parent"] if meta.get("parent") else None),
        status=Status(meta.get("status", "unplanned")),
        title=meta.get("title", "(untitled)"),
        created=meta.get("created", now_iso()),
        dir=goal_md.parent,
        body=body,
        prior_attempts=int(meta.get("prior_attempts", "0") or "0"),
        verified_sha=meta.get("verified_sha") or None,
    )


def write_node(node: Node) -> None:
    meta: dict = {
        "id": node.id,
        "parent": node.parent,
        "status": node.status.value,
        "title": node.title,
        "created": node.created,
        "prior_attempts": node.prior_attempts,
    }
    if node.verified_sha:
        meta["verified_sha"] = node.verified_sha
    node.dir.mkdir(parents=True, exist_ok=True)
    node.goal_path.write_text(fm_dump(meta, node.body), encoding="utf-8")


def set_status(node: Node, status: Status) -> None:
    node.status = status
    write_node(node)


# ---------- tree discovery ----------

def nodes_root(control_plane: Path) -> Path:
    return control_plane / NODES_DIRNAME


def walk_goal_files(control_plane: Path) -> Iterable[Path]:
    nr = nodes_root(control_plane)
    if not nr.is_dir():
        return
    for p in nr.rglob("goal.md"):
        yield p


def load_tree(control_plane: Path) -> Node:
    by_id: dict[str, Node] = {}
    for goal_md in walk_goal_files(control_plane):
        n = read_node(goal_md)
        by_id[n.id] = n
    if not by_id:
        raise FileNotFoundError(f"No nodes under {nodes_root(control_plane)}. Run `goalie init <goal>`.")

    root: Optional[Node] = None
    for n in by_id.values():
        if n.parent is None:
            if root is not None:
                raise ValueError(f"Multiple root nodes: {root.id} and {n.id}")
            root = n
        else:
            parent = by_id.get(n.parent)
            if parent is None:
                raise ValueError(f"Node {n.id} references missing parent {n.parent}")
            parent.children.append(n)
    if root is None:
        raise ValueError("No root node — every node has a parent")

    def order(n: Node) -> None:
        n.children.sort(key=lambda x: (x.created, x.id))
        for c in n.children:
            order(c)
    order(root)
    return root


def iter_tree(root: Node) -> Iterable[Node]:
    yield root
    for c in root.children:
        yield from iter_tree(c)


def short_display_id(node: Node, all_nodes: Iterable[Node]) -> str:
    """Shortest suffix of node.id (≥4 chars) that is unique among all_nodes."""
    other_ids = [n.id.lower() for n in all_nodes if n.id != node.id]
    tail = node.id.lower()
    for length in range(4, len(tail) + 1):
        suffix = tail[-length:]
        if not any(oid.endswith(suffix) for oid in other_ids):
            return suffix
    return tail


def find_by_id(control_plane: Path, ident: str) -> Node:
    """Accept full ULID, ≥4-char prefix or suffix (case-insensitive), or directory slug."""
    ident = ident.strip()
    if not ident:
        raise ValueError("Empty node id")
    root = load_tree(control_plane)
    nodes = list(iter_tree(root))
    slug_matches = [n for n in nodes if n.dir.name == ident]
    if len(slug_matches) == 1:
        return slug_matches[0]
    lo = ident.lower()
    matches = [n for n in nodes if n.id.lower().startswith(lo) or n.id.lower().endswith(lo)]
    if not matches:
        raise ValueError(f"No node matches '{ident}'")
    if len(matches) > 1:
        raise ValueError(f"Ambiguous id '{ident}' — matches {len(matches)} nodes")
    return matches[0]


# ---------- creating nodes ----------

def init_root(control_plane: Path, title: str, body: str = "") -> Node:
    nr = nodes_root(control_plane)
    nr.mkdir(parents=True, exist_ok=True)
    nid = mint_ulid()
    node_dir = nr / unique_slug(nr, title)
    node = Node(
        id=nid,
        parent=None,
        status=Status.unplanned,
        title=title,
        created=now_iso(),
        dir=node_dir,
        body=body or title,
    )
    write_node(node)
    return node


def create_child(control_plane: Path, parent: Node, title: str, body: str = "") -> Node:
    """Children live under `<control_plane>/nodes/<slug>` (flat, not nested by parent dir).
    Parent linkage is via frontmatter, not directory."""
    nr = nodes_root(control_plane)
    nr.mkdir(parents=True, exist_ok=True)
    slug = unique_slug(nr, title)
    child_dir = nr / slug
    child = Node(
        id=mint_ulid(),
        parent=parent.id,
        status=Status.unplanned,
        title=title,
        created=now_iso(),
        dir=child_dir,
        body=body or title,
    )
    write_node(child)
    return child


# ---------- appenders ----------

def append_attempt(node: Node, critique: str) -> None:
    node.attempts_path.parent.mkdir(parents=True, exist_ok=True)
    block = f"\n## {now_iso()} — rejected\n\n{critique.strip()}\n"
    with node.attempts_path.open("a") as f:
        f.write(block)


def latest_critique(node: Node) -> Optional[str]:
    """Return the most recent critique block from attempts.md (without header)."""
    if not node.attempts_path.exists():
        return None
    text = node.attempts_path.read_text().strip()
    if not text:
        return None
    parts = text.split("\n## ")
    last = parts[-1]
    lines = last.splitlines()
    return "\n".join(lines[1:]).strip() if len(lines) > 1 else None


def maybe_rollup_parent(child_id: str, cp: Path) -> list[Node]:
    """After a child is marked done, walk up and flip pending parents to
    needs_review if all their children are done. Recurses upward. Returns
    parents that transitioned (innermost first)."""
    root = load_tree(cp)
    by_id = {n.id: n for n in iter_tree(root)}
    rolled: list[Node] = []
    node = by_id.get(child_id)
    if node is None:
        return rolled
    parent_id = node.parent
    while parent_id:
        parent = by_id.get(parent_id)
        if parent is None:
            break
        if parent.status == Status.pending and all(c.status == Status.done for c in parent.children):
            set_status(parent, Status.needs_review)
            rolled.append(parent)
            parent_id = parent.parent
        else:
            break
    return rolled


