"""Stdlib polyfills for ulid / frontmatter. Swap internals here to restore real libs."""
import re
import secrets
import time

# ---------- ulid ----------

_B32 = "0123456789ABCDEFGHJKMNPQRSTVWXYZ"


def mint_ulid() -> str:
    ms = time.time_ns() // 1_000_000
    ts = "".join(_B32[(ms >> (5 * i)) & 0x1F] for i in range(9, -1, -1))
    n = int.from_bytes(secrets.token_bytes(10), "big")
    rs = "".join(_B32[(n >> (5 * i)) & 0x1F] for i in range(15, -1, -1))
    return ts + rs


# ---------- frontmatter ----------

_FENCE = "---\n"
_LINE_RE = re.compile(r"^(\w+):\s*(.*)$")
_ESCAPES = {"\\": "\\\\", '"': '\\"', "\n": "\\n"}
_UNESCAPES = {"\\\\": "\\", '\\"': '"', "\\n": "\n"}


def _escape(v: str) -> str:
    out = []
    for ch in v:
        out.append(_ESCAPES.get(ch, ch))
    return "".join(out)


def _unescape(v: str) -> str:
    out, i = [], 0
    while i < len(v):
        if v[i] == "\\" and i + 1 < len(v):
            pair = v[i : i + 2]
            if pair not in _UNESCAPES:
                raise ValueError(f"frontmatter: bad escape sequence: {pair!r}")
            out.append(_UNESCAPES[pair])
            i += 2
        else:
            out.append(v[i])
            i += 1
    return "".join(out)


def fm_load(text: str) -> tuple[dict[str, str], str]:
    """Parse frontmatter. Returns ({}, text) if no fences. Raises ValueError on malformed."""
    if not text.startswith(_FENCE):
        return {}, text
    end = text.find("\n" + _FENCE, len(_FENCE))
    if end == -1:
        raise ValueError("frontmatter: missing closing '---'")
    header = text[len(_FENCE) : end]
    body = text[end + 1 + len(_FENCE) :]
    meta: dict[str, str] = {}
    for line in header.splitlines():
        if not line.strip():
            continue
        m = _LINE_RE.match(line)
        if not m:
            raise ValueError(f"frontmatter: malformed line: {line!r}")
        k, raw = m.group(1), m.group(2)
        if raw.startswith('"'):
            if not raw.endswith('"') or len(raw) < 2:
                raise ValueError(f"frontmatter: unterminated quote on key {k!r}")
            meta[k] = _unescape(raw[1:-1])
        else:
            meta[k] = raw
    return meta, body


def fm_dump(meta: dict, body: str) -> str:
    """Serialize. Skips None values. Always emits quoted form."""
    lines = [f'{k}: "{_escape(str(v))}"' for k, v in meta.items() if v is not None]
    return _FENCE + "\n".join(lines) + "\n" + _FENCE + body
