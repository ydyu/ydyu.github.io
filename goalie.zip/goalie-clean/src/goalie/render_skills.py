"""Scaffold canonical skills into `.goalie/skills/` and render vendor files.

`scaffold_skills` runs once on first `init --cli`; subsequent runs leave
existing files alone (skills are user-editable). `render_vendor_files` is
idempotent — vendor outputs are derived and may be regenerated.

`render_goalie_md` writes a single `GOALIE.md` at the repo root (goalie-owned,
always overwritten). Vendor-owned files (`CLAUDE.md`, `GEMINI.md`, `AGENTS.md`,
`.github/copilot-instructions.md`) are never touched; `vendor_instructions`
returns the text to print so the user or their CLI agent can wire them up.
"""
from __future__ import annotations

from importlib import resources
from pathlib import Path
from typing import Iterable

ROLES = ("planner", "solver", "reviewer")
SKILL_FILES = ("_base.md", *[f"{r}.md" for r in ROLES])
GOALIE_AGENT_DESCRIPTION = (
    "Goalie workflow agent; tell it to act as planner, solver, or reviewer "
    "— switchable at any time during the chat."
)
ALL_VENDORS = ("copilot", "claude", "gemini")


def _read_template(name: str) -> str:
    return resources.files("goalie.templates.skills").joinpath(name).read_text()


def _read_integration(vendor: str) -> str:
    return resources.files("goalie.templates.integration").joinpath(f"{vendor}.md").read_text()


def _read_agent_template() -> str:
    return resources.files("goalie.templates.integration").joinpath("goalie.md").read_text()


def scaffold_skills(control_plane: Path, *, force: bool = False) -> list[Path]:
    """Copy skill templates into `<control_plane>/skills/`. Pass force=True to overwrite."""
    skills_dir = control_plane / "skills"
    skills_dir.mkdir(parents=True, exist_ok=True)
    written: list[Path] = []
    for name in SKILL_FILES:
        dst = skills_dir / name
        if force or not dst.exists():
            dst.write_text(_read_template(name))
        written.append(dst)
    return written


def _read_skill(control_plane: Path, name: str) -> str:
    return (control_plane / "skills" / name).read_text()


def render_goalie_md(control_plane: Path, target_repo: Path) -> Path:
    """Write `GOALIE.md` at the repo root from `.goalie/skills/_base.md`. Always overwrites."""
    dst = target_repo / "GOALIE.md"
    dst.write_text(_read_skill(control_plane, "_base.md"))
    return dst


def render_vendor_files(
    control_plane: Path,
    target_repo: Path,
    vendors: Iterable[str],
) -> list[Path]:
    """Render per-role files for each vendor. Idempotent.

    Does NOT write workspace-level vendor-owned files (CLAUDE.md, GEMINI.md,
    AGENTS.md, .github/copilot-instructions.md). Call `vendor_instructions` to
    get the text describing how to wire those up.
    """
    role_skills = {r: _read_skill(control_plane, f"{r}.md") for r in ROLES}
    agent_content = _read_agent_template()
    out: list[Path] = []

    for v in vendors:
        if v == "copilot":
            for role, content in role_skills.items():
                p = target_repo / ".github" / "prompts" / f"{role}.prompt.md"
                p.parent.mkdir(parents=True, exist_ok=True)
                fm = (
                    "---\n"
                    "mode: agent\n"
                    f"description: Run as the goalie {role} for one turn.\n"
                    "---\n\n"
                )
                p.write_text(fm + content)
                out.append(p)

            agents_dir = target_repo / ".github" / "agents"
            agents_dir.mkdir(parents=True, exist_ok=True)
            p = agents_dir / "goalie.md"
            p.write_text(
                "---\n"
                "name: goalie\n"
                f'description: "{GOALIE_AGENT_DESCRIPTION}"\n'
                "---\n\n"
                + agent_content
            )
            out.append(p)

        elif v == "claude":
            for role, content in role_skills.items():
                p = target_repo / ".claude" / "commands" / f"{role}.md"
                p.parent.mkdir(parents=True, exist_ok=True)
                fm = (
                    "---\n"
                    f"description: Run as the goalie {role} for one turn.\n"
                    "---\n\n"
                )
                p.write_text(fm + content)
                out.append(p)

            agents_dir = target_repo / ".claude" / "agents"
            agents_dir.mkdir(parents=True, exist_ok=True)
            p = agents_dir / "goalie.md"
            p.write_text(
                "---\n"
                "name: goalie\n"
                f"description: {GOALIE_AGENT_DESCRIPTION}\n"
                "---\n\n"
                + agent_content
            )
            out.append(p)

        elif v == "gemini":
            for role, content in role_skills.items():
                p = target_repo / ".gemini" / "commands" / f"{role}.toml"
                p.parent.mkdir(parents=True, exist_ok=True)
                escaped = content.replace('"""', '\\"\\"\\"')
                toml = (
                    f'description = "Run as the goalie {role} for one turn."\n'
                    f'prompt = """\n{escaped}"""\n'
                )
                p.write_text(toml)
                out.append(p)

        else:
            raise ValueError(f"Unknown vendor: {v!r}. Expected: copilot, claude, gemini.")

    return out


def vendor_instructions(vendors: Iterable[str]) -> str:
    """Return the wiring-instruction text for each vendor, concatenated."""
    parts = [_read_integration(v) for v in vendors]
    return "\n".join(parts)
