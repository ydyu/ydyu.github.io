"""Thin subprocess wrapper around git, run inside `target_repo`.

All callers pass an explicit `cwd` (the resolved `target_repo` from Config).
Trailers are our public contract — every commit goalie creates includes
`Goalie-Id: <id>`.
"""
from __future__ import annotations

import subprocess
from pathlib import Path

EMPTY_TREE_SHA = "4b825dc642cb6eb9a060e54bf8d69288fbee4904"


class GitError(RuntimeError):
    pass


def _run(cmd: list[str], cwd: Path, check: bool = True, capture: bool = True) -> subprocess.CompletedProcess:
    r = subprocess.run(cmd, cwd=str(cwd), text=True, capture_output=capture)
    if check and r.returncode != 0:
        raise GitError(f"{' '.join(cmd)} → {r.returncode}\n{r.stderr}")
    return r


def is_repo(cwd: Path) -> bool:
    r = subprocess.run(
        ["git", "rev-parse", "--is-inside-work-tree"],
        cwd=str(cwd), text=True, capture_output=True,
    )
    return r.returncode == 0 and r.stdout.strip() == "true"


def init(cwd: Path) -> None:
    _run(["git", "init", "-q"], cwd=cwd)
    r = subprocess.run(["git", "config", "user.email"], cwd=str(cwd), text=True, capture_output=True)
    if r.returncode != 0 or not r.stdout.strip():
        _run(["git", "config", "user.email", "goalie@local"], cwd=cwd)
        _run(["git", "config", "user.name", "Goalie"], cwd=cwd)


def has_any_commits(cwd: Path) -> bool:
    r = subprocess.run(["git", "rev-parse", "HEAD"], cwd=str(cwd), text=True, capture_output=True)
    return r.returncode == 0


def has_changes(cwd: Path) -> bool:
    return bool(_run(["git", "status", "--porcelain"], cwd=cwd).stdout.strip())


def git_diff(cwd: Path) -> str:
    if not has_any_commits(cwd):
        # diff working tree against the empty tree
        _run(["git", "add", "-N", "."], cwd=cwd, check=False)
        return _run(
            ["git", "diff", "--no-color", EMPTY_TREE_SHA],
            cwd=cwd, check=False,
        ).stdout
    return _run(["git", "diff", "--no-color", "HEAD"], cwd=cwd).stdout


def head_sha(cwd: Path) -> str:
    """Return HEAD commit SHA. Raises GitError if no commits."""
    return _run(["git", "rev-parse", "HEAD"], cwd=cwd).stdout.strip()


def head_has_goalie_id(cwd: Path, node_id: str) -> bool:
    """Return True if HEAD commit message contains 'Goalie-Id: <node_id>' trailer."""
    if not has_any_commits(cwd):
        return False
    body = _run(["git", "log", "-1", "--pretty=format:%B", "HEAD"], cwd=cwd).stdout
    return f"Goalie-Id: {node_id}" in body


def dirty_tracked_files(cwd: Path) -> list[str]:
    """Return tracked files with uncommitted changes (staged or unstaged, not untracked)."""
    r = _run(["git", "status", "--porcelain"], cwd=cwd, check=False)
    files = []
    for line in r.stdout.splitlines():
        if not line.startswith("??"):
            files.append(line[3:])
    return files


def has_changes_staged(cwd: Path) -> bool:
    if not has_any_commits(cwd):
        # no HEAD: any file in the index counts as staged
        return bool(_run(["git", "ls-files", "--cached"], cwd=cwd).stdout.strip())
    r = _run(["git", "diff", "--cached", "--name-only"], cwd=cwd)
    return bool(r.stdout.strip())
