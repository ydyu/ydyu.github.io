"""Renderer for `goalie next` output.

YAML frontmatter (metadata) + markdown body. User-authored content (goal
descriptions, prior critiques, human answers) is wrapped in fenced blocks
so an agent can treat it as data rather than instruction.
"""
from __future__ import annotations

import json
import re
from typing import Optional

from .config import Config
from .store import Node, Status, latest_critique

TRIGGER_PATTERNS = [
    re.compile(r"\bignore (all |any )?previous\b", re.I),
    re.compile(r"\binstead\b.{0,40}\b(do|act|behave)\b", re.I),
    re.compile(r"\bnow act as\b", re.I),
    re.compile(r"^\s*system\s*:", re.I | re.M),
]


def _scrub(text: str) -> str:
    """Stamp out known prompt-injection trigger phrases inside user content.
    Replaces matches with a marker; leaves a trace so a human reviewer can
    spot tampering."""
    out = text
    for pat in TRIGGER_PATTERNS:
        out = pat.sub("[goalie-redacted: trigger phrase]", out)
    return out


def _fence(text: str) -> str:
    """Wrap user-authored content in a triple-backtick block, escaping any
    inner triple-backticks by switching to a longer fence."""
    text = _scrub(text.strip())
    fence = "```"
    while fence in text:
        fence += "`"
    return f"{fence}\n{text}\n{fence}"


def _collect_ancestors(node: Node, by_id: dict[str, Node]) -> list[Node]:
    """Return ancestor chain [root, ..., parent] for the given node."""
    chain = []
    cur_id = node.parent
    while cur_id:
        anc = by_id.get(cur_id)
        if anc is None:
            break
        chain.append(anc)
        cur_id = anc.parent
    chain.reverse()
    return chain


def _report_back(nid: str, role: str) -> dict:
    base: dict = {"blocked": "use your ask-user-questions tool to gather answers, then update the task spec before calling goalie plan"}
    if role == "planner":
        base["done"] = f"goalie plan {nid}"
    elif role == "solver":
        base["done"] = f"goalie done {nid}"
    elif role == "reviewer":
        base["approve"] = f"goalie approve {nid}"
        base["reject"] = f'goalie reject {nid} "<reason>"'
    else:
        base["done"] = f"goalie done {nid}"
    return base


def render_next(
    cfg: Config,
    node: Node,
    role: str,
    parent: Optional[Node],
    by_id: Optional[dict[str, Node]] = None,
) -> str:
    """Produce the markdown+frontmatter document `goalie next` returns."""
    by_id = by_id or {}
    nid = node.id
    fm = {
        "node_id": nid,
        "role": role,
        "status": node.status.value,
        "target_repo": str(cfg.target_repo),
        "parent_id": parent.id if parent else None,
        "parent_goal": parent.title if parent else None,
        "report_back": _report_back(nid, role),
        "prior_attempts": int(node.prior_attempts),
    }
    fm_text = json.dumps(fm, indent=2)

    parts = [f"---\n{fm_text}\n---", ""]

    self_body = node.body if (node.body and node.body != node.title) else None
    if self_body:
        parts.append("## Goal\n")
        parts.append(_fence(self_body))
        parts.append("")

    parts.append("## Task\n")
    if node.task_path.exists() and node.task_path.read_text().strip():
        parts.append(_fence(node.task_path.read_text()))
    else:
        # planner case: the goal itself is the source material
        parts.append(_fence(node.body or node.title))
    parts.append("")

    parts.append("## Acceptance\n")
    if node.verify_path.exists() and node.verify_path.read_text().strip():
        parts.append(_fence(node.verify_path.read_text()))
    else:
        parts.append("_No `verify.md` written yet — planner produces this._")
    parts.append("")

    ancestors = _collect_ancestors(node, by_id)

    parts.append("## Context\n")
    ctx_lines = []
    if ancestors:
        ctx_lines.append("Ancestors:")
        for anc in ancestors:
            anc_body = anc.body if (anc.body and anc.body != anc.title) else ""
            ctx_lines.append(f"  `{anc.short_id}` {anc.title}")
            if anc_body:
                for line in _scrub(anc_body).splitlines():
                    ctx_lines.append(f"  > {line}")
            ctx_lines.append("")
    ctx_lines.append(f"Target repo: `{cfg.target_repo}`")
    parts.append("\n".join(ctx_lines))
    parts.append("")

    if node.prior_attempts > 0:
        critique = latest_critique(node)
        if critique:
            parts.append("## Prior reviewer feedback\n")
            parts.append(_fence(critique))
            parts.append("")

    if role == "planner" and node.children and node.status == Status.rejected:
        parts.append("## Existing decomposition\n")
        child_lines = [f"- `{c.short_id}` {c.title} [{c.status.value}]" for c in node.children]
        parts.append("\n".join(child_lines))
        parts.append("")

    return "\n".join(parts).rstrip() + "\n"


def render_no_work(role: str, counts: dict[str, int]) -> str:
    lines = [f"No tasks for role '{role}'.", ""]
    lines.append("Tree state:")
    for status_name, n in counts.items():
        lines.append(f"  - {n} node(s) `{status_name}`")
    lines.append("")
    lines.append("Re-run when other roles have advanced.")
    return "\n".join(lines) + "\n"
