"""`goalie done <id>` — solver submit: pending → needs_review."""
from __future__ import annotations

from pathlib import Path
from typing import Optional

from . import VerbResult, EXIT_OK, EXIT_BAD_REQUEST
from ..config import resolve_control_plane
from ..store import Status, locked_node, set_status


def run(cwd: Path, ident: str, *, cp_override: Optional[str] = None) -> VerbResult:
    cp = resolve_control_plane(cwd, override=cp_override)
    with locked_node(cp, ident) as node:
        if node.children:
            return VerbResult(
                f"ERROR: node `{node.short_id}` has children; submission happens automatically "
                "when the last child is verified.\n",
                exit_code=EXIT_BAD_REQUEST, stderr=True,
            )
        if node.status not in (Status.pending, Status.rejected):
            return VerbResult(
                f"ERROR: node `{node.short_id}` is `{node.status.value}`, expected `pending` or `rejected`.\n",
                exit_code=EXIT_BAD_REQUEST, stderr=True,
            )
        set_status(node, Status.needs_review)
    return VerbResult(f"`{node.short_id}` submitted → needs_review.\n", exit_code=EXIT_OK)
