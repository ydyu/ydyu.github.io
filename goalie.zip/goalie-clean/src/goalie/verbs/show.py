"""`goalie show <ident>` — read-only per-node inspector."""
from __future__ import annotations

from pathlib import Path
from typing import Optional

from . import VerbResult, EXIT_OK, EXIT_BAD_REQUEST
from ..config import resolve_control_plane
from ..store import find_by_id


def run(cwd: Path, ident: str, *, cp_override: Optional[str] = None) -> VerbResult:
    cp = resolve_control_plane(cwd, override=cp_override)
    try:
        node = find_by_id(cp, ident)
    except ValueError as e:
        return VerbResult(f"ERROR: {e}\n", exit_code=EXIT_BAD_REQUEST, stderr=True)

    lines = [f"# `{node.short_id}` {node.title}  [{node.status.value}]", ""]

    lines.append("## Goal")
    body = node.body if (node.body and node.body != node.title) else None
    lines.append(body if body else "_not written_")
    lines.append("")

    lines.append("## Task")
    if node.task_path.exists():
        content = node.task_path.read_text().strip()
        lines.append(content if content else "_not yet planned_")
    else:
        lines.append("_not yet planned_")
    lines.append("")

    lines.append("## Acceptance")
    if node.verify_path.exists():
        content = node.verify_path.read_text().strip()
        lines.append(content if content else "_not yet planned_")
    else:
        lines.append("_not yet planned_")
    lines.append("")

    return VerbResult("\n".join(lines).rstrip() + "\n", exit_code=EXIT_OK)
