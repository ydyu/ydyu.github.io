"""`goalie reject <id> "<reason>"` — reviewer reject: needs_review → rejected."""
from __future__ import annotations

from pathlib import Path
from typing import Optional

from . import VerbResult, EXIT_OK, EXIT_BAD_REQUEST
from ..config import resolve_control_plane
from ..store import Status, append_attempt, locked_node, set_status


def run(cwd: Path, ident: str, reason: str, *, cp_override: Optional[str] = None) -> VerbResult:
    if not reason or not reason.strip():
        return VerbResult(
            "ERROR: reject requires a non-empty reason.\n",
            exit_code=EXIT_BAD_REQUEST, stderr=True,
        )
    cp = resolve_control_plane(cwd, override=cp_override)
    with locked_node(cp, ident) as node:
        if node.status != Status.needs_review:
            return VerbResult(
                f"ERROR: node `{node.short_id}` is `{node.status.value}`, expected `needs_review`.\n",
                exit_code=EXIT_BAD_REQUEST, stderr=True,
            )
        append_attempt(node, reason)
        node.prior_attempts = (node.prior_attempts or 0) + 1
        set_status(node, Status.rejected)

    if node.children:
        return VerbResult(
            f"`{node.short_id}` rejected → rejected. Planner will pick it up.\n",
            exit_code=EXIT_OK,
        )
    return VerbResult(
        f"`{node.short_id}` rejected → rejected. Solver will pick it up next.\n",
        exit_code=EXIT_OK,
    )
