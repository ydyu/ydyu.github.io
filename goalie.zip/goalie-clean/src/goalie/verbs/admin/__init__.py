"""Admin verbs — scaffolding for state recovery. Marked temporary.

These are NOT in skill prompts and are hidden from default --help.
They exist to recover from bad tree states without manual YAML editing.
"""
