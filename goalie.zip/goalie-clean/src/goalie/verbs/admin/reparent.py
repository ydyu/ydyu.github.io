"""`goalie admin reparent <id> <new-parent-id>` — change a node's parent.

Cycle-safe: errors if new_parent is a descendant of the node being reparented.
"""
from __future__ import annotations

from pathlib import Path

from typing import Optional

from .. import VerbResult, EXIT_OK, EXIT_BAD_REQUEST
from ...config import resolve_control_plane
from ...store import find_by_id, iter_tree, locked_node, write_node


def run(cwd: Path, ident: str, new_parent_ident: str, *, cp_override: Optional[str] = None) -> VerbResult:
    cp = resolve_control_plane(cwd, override=cp_override)
    with locked_node(cp, ident) as node:
        new_parent = find_by_id(cp, new_parent_ident)

        if node.id == new_parent.id:
            return VerbResult(
                "ERROR: a node cannot be its own parent.\n",
                exit_code=EXIT_BAD_REQUEST, stderr=True,
            )
        # Cycle check: new_parent must not be a descendant of node
        descendant_ids = {n.id for n in iter_tree(node)}
        if new_parent.id in descendant_ids:
            return VerbResult(
                f"ERROR: `{new_parent.short_id}` is a descendant of `{node.short_id}`; "
                "reparenting would create a cycle.\n",
                exit_code=EXIT_BAD_REQUEST, stderr=True,
            )

        old_parent_id = node.parent
        node.parent = new_parent.id
        write_node(node)

    return VerbResult(
        f"`{node.short_id}` reparented: {old_parent_id} → {new_parent.id}\n",
        exit_code=EXIT_OK,
    )
