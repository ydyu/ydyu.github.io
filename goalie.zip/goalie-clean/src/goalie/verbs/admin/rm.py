"""`goalie admin rm <id> [--recursive]` — delete a node.

Without --recursive, errors if the node has children.
With --recursive, deletes the node and all its descendants.
"""
from __future__ import annotations

import shutil
from pathlib import Path

from typing import Optional

from .. import VerbResult, EXIT_OK, EXIT_BAD_REQUEST
from ...config import resolve_control_plane
from ...store import iter_tree, locked_node


def run(cwd: Path, ident: str, *, recursive: bool = False, cp_override: Optional[str] = None) -> VerbResult:
    cp = resolve_control_plane(cwd, override=cp_override)
    with locked_node(cp, ident) as node:
        if node.parent is None:
            return VerbResult(
                "ERROR: cannot remove the root node.\n",
                exit_code=EXIT_BAD_REQUEST, stderr=True,
            )
        if node.children and not recursive:
            return VerbResult(
                f"ERROR: `{node.short_id}` has {len(node.children)} child(ren). "
                "Use --recursive to delete the subtree.\n",
                exit_code=EXIT_BAD_REQUEST, stderr=True,
            )
        to_delete = list(iter_tree(node))
        deleted = []
        for n in to_delete:
            if n.dir.exists():
                shutil.rmtree(n.dir)
                deleted.append(n.short_id)

    count = len(deleted)
    noun = "node" if count == 1 else "nodes"
    ids = ", ".join(f"`{d}`" for d in deleted)
    return VerbResult(
        f"Deleted {count} {noun}: {ids}\n",
        exit_code=EXIT_OK,
    )
