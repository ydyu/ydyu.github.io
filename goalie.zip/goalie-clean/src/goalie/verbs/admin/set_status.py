"""`goalie admin set-status <id> <status>` — bypass the state machine.

WARNING: may produce states the normal verbs can't reach; you own the consequences.
"""
from __future__ import annotations

from pathlib import Path

from typing import Optional

from .. import VerbResult, EXIT_OK, EXIT_BAD_REQUEST
from ...config import resolve_control_plane
from ...store import Status, locked_node, set_status


def run(cwd: Path, ident: str, status_value: str, *, cp_override: Optional[str] = None) -> VerbResult:
    try:
        new_status = Status(status_value)
    except ValueError:
        valid = ", ".join(s.value for s in Status)
        return VerbResult(
            f"ERROR: unknown status '{status_value}'. Valid: {valid}\n",
            exit_code=EXIT_BAD_REQUEST, stderr=True,
        )
    cp = resolve_control_plane(cwd, override=cp_override)
    with locked_node(cp, ident) as node:
        old_status = node.status
        set_status(node, new_status)
    return VerbResult(
        f"`{node.short_id}` {old_status.value} → {new_status.value}\n",
        exit_code=EXIT_OK,
    )
