"""`goalie init` — create the control plane and initial root goal."""
from __future__ import annotations

from pathlib import Path
from typing import Optional

from . import VerbResult, EXIT_OK, EXIT_BAD_REQUEST
from .. import git as gitmod
from ..config import Config, DEFAULT_ROLES
from ..render_skills import scaffold_skills, render_goalie_md, render_vendor_files, vendor_instructions
from ..store import GOALIE_DIR, init_root, index_lock

_GITIGNORE_PATTERNS = [".goalie/", "goalie_task_*.md", "goalie_verify_*.md", "goalie_goal_*.md"]


def _update_gitignore(target_path: Path) -> None:
    gi = target_path / ".gitignore"
    existing = gi.read_text() if gi.exists() else ""
    to_add = [p for p in _GITIGNORE_PATTERNS if p not in existing]
    if not to_add:
        return
    sep = "\n" if existing and not existing.endswith("\n") else ""
    gi.write_text(existing + sep + "\n".join(to_add) + "\n")


def run(
    cwd: Path,
    goal: str,
    *,
    control_plane: bool = False,
    target: Optional[str] = None,
    cli_vendors: Optional[list[str]] = None,
) -> VerbResult:
    cp_dir = (cwd / GOALIE_DIR).resolve()

    if control_plane and not target:
        return VerbResult(
            "ERROR: --control-plane requires --target <path>.\n",
            exit_code=EXIT_BAD_REQUEST, stderr=True,
        )

    if target:
        target_path = (cwd / target).resolve() if not Path(target).is_absolute() else Path(target).resolve()
    else:
        target_path = cwd.resolve()

    if not target_path.exists():
        return VerbResult(
            f"ERROR: target_repo '{target_path}' does not exist.\n",
            exit_code=EXIT_BAD_REQUEST, stderr=True,
        )

    if (cp_dir / "config.yaml").exists():
        return VerbResult(
            f"ERROR: {cp_dir} already initialized.\n",
            exit_code=EXIT_BAD_REQUEST, stderr=True,
        )

    vendors = list(cli_vendors) if cli_vendors else []

    cp_dir.mkdir(parents=True, exist_ok=True)
    cfg = Config(
        target_repo=target_path,
        roles=dict(DEFAULT_ROLES),
        control_plane_dir=cp_dir,
        vendors=vendors,
    )
    cfg.save()

    if not gitmod.is_repo(target_path):
        gitmod.init(target_path)

    _update_gitignore(target_path)

    with index_lock(cp_dir):
        root = init_root(cp_dir, title=goal, body=goal)

    lines = [
        f"Initialized goalie control plane at {cp_dir}",
        f"target_repo: {target_path}",
        f"Root node: {root.short_id}  (status: {root.status.value})",
    ]

    if vendors:
        skill_paths = scaffold_skills(cp_dir)
        goalie_md = render_goalie_md(cp_dir, target_path)
        rendered = render_vendor_files(cp_dir, target_path, vendors)
        lines.append("")
        lines.append("Skills scaffolded:")
        for p in skill_paths:
            lines.append(f"  + {p}")
        lines.append("Vendor files written:")
        lines.append(f"  + {goalie_md}")
        for p in rendered:
            lines.append(f"  + {p}")
        lines.append("")
        lines.append(vendor_instructions(vendors))

    if vendors or control_plane:
        lines.append("")
        lines.append(f"export GOALIE_CP={cp_dir}")
        lines.append("# Paste the line above into each target-repo shell session.")

    lines.append("")
    lines.append("Next: `goalie next --role planner`")
    return VerbResult("\n".join(lines) + "\n", exit_code=EXIT_OK)
