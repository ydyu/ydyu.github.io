"""`goalie tree` — print the goal tree as a markdown-friendly outline."""
from __future__ import annotations

from pathlib import Path

from typing import Optional

from . import VerbResult, EXIT_OK
from ..config import resolve_control_plane
from ..store import Node, Status, load_tree, iter_tree, short_display_id


_STATUS_GLYPHS = {
    Status.unplanned: "◯",
    Status.pending: "▢",
    Status.needs_review: "▼",
    Status.rejected: "✗",
    Status.done: "✓",
}


def _render(
    node: Node,
    ancestors_last: list[bool],
    is_last: Optional[bool],
    lines: list[str],
    all_nodes: list[Node],
) -> None:
    # Box-drawing connectors survive markdown re-rendering (e.g. `goalie tree | glow`)
    # because they aren't whitespace; plain-space indent gets collapsed.
    if is_last is None:
        prefix = ""
        cont_prefix = "  "
    else:
        ancestor_part = "".join("   " if last else "│  " for last in ancestors_last)
        own_part = "└─ " if is_last else "├─ "
        cont_self = "   " if is_last else "│  "
        prefix = ancestor_part + own_part
        cont_prefix = ancestor_part + cont_self + "  "

    # Shape glyph encodes structure (has children) independent of status.
    glyph = "┬" if node.children else _STATUS_GLYPHS.get(node.status, "?")
    sid = short_display_id(node, all_nodes)
    lines.append(f"{prefix}{glyph} `{sid}` {node.title} [{node.status.value}]")

    new_ancestors = ancestors_last if is_last is None else ancestors_last + [is_last]
    children = node.children
    for i, c in enumerate(children):
        _render(c, new_ancestors, i == len(children) - 1, lines, all_nodes)


def run(cwd: Path, *, cp_override: Optional[str] = None) -> VerbResult:
    cp = resolve_control_plane(cwd, override=cp_override)
    root = load_tree(cp)
    all_nodes = list(iter_tree(root))
    lines: list[str] = []
    _render(root, [], None, lines, all_nodes)
    return VerbResult("\n".join(lines) + "\n", exit_code=EXIT_OK)
