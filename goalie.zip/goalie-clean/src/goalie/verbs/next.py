"""`goalie next --role <role>` — pull the next task for a role."""
from __future__ import annotations

from collections import Counter
from pathlib import Path
from typing import Optional

from . import VerbResult, EXIT_OK, EXIT_NO_WORK, EXIT_BAD_REQUEST
from ..config import Config, resolve_control_plane
from ..render import render_next, render_no_work
from ..store import Node, Status, find_by_id, load_tree, iter_tree


def _role_matches(n: Node, role: str) -> bool:
    """Structural filter on top of watchlist status check.

    solver: leaf-only (no children)
    planner: unplanned any node; rejected only parent nodes
    reviewer + custom: no structural restriction
    """
    has_children = bool(n.children)
    if role == "solver":
        return not has_children
    if role == "planner":
        if n.status == Status.rejected:
            return has_children  # parent rejection only; leaves go to solver
        return True
    return True


def _find_for_role(root: Node, role: str, watchlist: list[str]) -> Optional[Node]:
    """Deepest node whose status is in `watchlist` and passes the structural
    filter for this role. DFS, prefer deeper matches."""
    statuses = set(watchlist)
    found: Optional[Node] = None
    found_depth = -1

    def visit(n: Node, depth: int) -> None:
        nonlocal found, found_depth
        if n.status.value in statuses and _role_matches(n, role):
            if depth > found_depth:
                found = n
                found_depth = depth
        for c in n.children:
            visit(c, depth + 1)

    visit(root, 0)
    return found


def run(cwd: Path, role: str, *, ident: Optional[str] = None, cp_override: Optional[str] = None) -> VerbResult:
    cp = resolve_control_plane(cwd, override=cp_override)
    cfg = Config.load(cp)

    if role not in cfg.roles:
        return VerbResult(
            f"ERROR: unknown role '{role}'. Configured: {sorted(cfg.roles)}\n",
            exit_code=EXIT_BAD_REQUEST, stderr=True,
        )

    root = load_tree(cp)
    watchlist = cfg.watchlist(role)

    if ident:
        try:
            node = find_by_id(cp, ident)
        except ValueError as e:
            return VerbResult(f"ERROR: {e}\n", exit_code=EXIT_BAD_REQUEST, stderr=True)

        if node.status.value not in watchlist or not _role_matches(node, role):
            return VerbResult(
                f"ERROR: node `{node.short_id}` ({node.status.value}) is not actionable for role '{role}'.\n",
                exit_code=EXIT_BAD_REQUEST, stderr=True,
            )
    else:
        node = _find_for_role(root, role, watchlist)

    if node is None:
        counts = Counter(n.status.value for n in iter_tree(root))
        return VerbResult(
            render_no_work(role, counts),
            exit_code=EXIT_NO_WORK,
        )

    by_id = {n.id: n for n in iter_tree(root)}
    parent = by_id.get(node.parent) if node.parent else None
    text = render_next(cfg, node, role, parent, by_id)
    return VerbResult(text, exit_code=EXIT_OK)
