"""Verb modules — one per CLI command. Each returns a VerbResult."""
from dataclasses import dataclass

EXIT_OK = 0
EXIT_FATAL = 40
EXIT_LOCK_CONTENTION = 41
EXIT_NO_WORK = 42
EXIT_BAD_REQUEST = 43


@dataclass
class VerbResult:
    text: str
    exit_code: int = EXIT_OK
    stderr: bool = False  # whether to emit on stderr instead of stdout
