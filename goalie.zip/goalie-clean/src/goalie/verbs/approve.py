"""`goalie approve <id>` — reviewer accept: needs_review → done."""
from __future__ import annotations

from pathlib import Path
from typing import Optional

from . import VerbResult, EXIT_OK, EXIT_BAD_REQUEST
from .. import git as gitmod
from ..config import Config, resolve_control_plane
from ..store import Status, locked_node, maybe_rollup_parent, set_status


def run(cwd: Path, ident: str, *, cp_override: Optional[str] = None) -> VerbResult:
    cp = resolve_control_plane(cwd, override=cp_override)
    cfg = Config.load(cp)
    target = cfg.target_repo

    dirty = gitmod.dirty_tracked_files(target)
    if dirty:
        file_list = "\n".join(f"  {f}" for f in sorted(dirty))
        return VerbResult(
            f"ERROR: working tree has uncommitted tracked changes; "
            f"commit before approving.\n{file_list}\n",
            exit_code=EXIT_BAD_REQUEST, stderr=True,
        )

    with locked_node(cp, ident) as node:
        if node.status != Status.needs_review:
            return VerbResult(
                f"ERROR: node `{node.short_id}` is `{node.status.value}`, expected `needs_review`.\n",
                exit_code=EXIT_BAD_REQUEST, stderr=True,
            )

        sha = gitmod.head_sha(target) if gitmod.has_any_commits(target) else ""
        has_trailer = gitmod.head_has_goalie_id(target, node.id) if sha else False

        if sha:
            node.verified_sha = sha
        set_status(node, Status.done)
        rolled = maybe_rollup_parent(node.id, cp)

    # Clean up reviewer commit staging file if present
    commit_file = target / f"goalie_commit_{node.id}.md"
    if commit_file.exists():
        commit_file.unlink()

    warning = ""
    if sha and not has_trailer:
        warning = (
            f"WARNING: HEAD doesn't reference `{node.short_id}`; "
            f"consider amending to add `Goalie-Id: {node.id}` "
            "for `git log --grep` searchability."
        )

    parts = [f"`{node.short_id}` approved → done."]
    if sha:
        parts.append(f"verified_sha: {sha[:10]}")
    if warning:
        parts.append(warning)
    if rolled:
        rollup_desc = ", ".join(
            f"`{r.short_id}` (pending → needs_review)" for r in rolled
        )
        parts.append(f"Rolled up: {rollup_desc}")

    return VerbResult("\n".join(parts) + "\n", exit_code=EXIT_OK)
