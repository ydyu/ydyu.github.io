"""`goalie doctor [--prune]` — report or remove orphan node directories.

Orphan: a dir under `.goalie/nodes/` with no valid goal.md tracked by the
tree. Caused by agents writing raw ULIDs or mis-guessed slugs as dir names.
"""
from __future__ import annotations

import shutil
from pathlib import Path

from typing import Optional

from . import VerbResult, EXIT_OK, EXIT_BAD_REQUEST
from ..config import resolve_control_plane
from ..store import load_tree, iter_tree, nodes_root


def run(cwd: Path, *, prune: bool = False, cp_override: Optional[str] = None) -> VerbResult:
    cp = resolve_control_plane(cwd, override=cp_override)
    nr = nodes_root(cp)

    if not nr.is_dir():
        return VerbResult("No nodes directory found.\n", exit_code=EXIT_OK)

    try:
        root = load_tree(cp)
        known_dirs = {n.dir.resolve() for n in iter_tree(root)}
    except FileNotFoundError:
        known_dirs = set()

    orphans = sorted(
        d for d in nr.iterdir()
        if d.is_dir() and d.resolve() not in known_dirs
    )

    if not orphans:
        return VerbResult("No orphan node directories.\n", exit_code=EXIT_OK)

    lines = [f"{len(orphans)} orphan dir(s) in {nr}:"]
    for d in orphans:
        contents = sorted(f.name for f in d.iterdir() if f.is_file())
        lines.append(f"  {d.name}/  [{', '.join(contents) or 'empty'}]")

    if prune:
        for d in orphans:
            shutil.rmtree(d)
        lines += ["", f"Pruned {len(orphans)} orphan dir(s)."]
        return VerbResult("\n".join(lines) + "\n", exit_code=EXIT_OK)

    lines += ["", "Re-run with --prune to delete."]
    return VerbResult("\n".join(lines) + "\n", exit_code=EXIT_BAD_REQUEST)
