"""`goalie cli` verbs — manage vendor CLI integrations after init."""
from __future__ import annotations

from pathlib import Path

from . import VerbResult, EXIT_OK, EXIT_BAD_REQUEST
from ..config import Config, resolve_control_plane
from ..render_skills import (
    ALL_VENDORS,
    scaffold_skills,
    render_goalie_md,
    render_vendor_files,
    vendor_instructions,
)


def init_(
    cwd: Path,
    vendors: list[str],
    *,
    force: bool = False,
    cp_override: str | None = None,
) -> VerbResult:
    cp_dir = resolve_control_plane(cwd, override=cp_override)
    cfg = Config.load(cp_dir)

    if not vendors and not cfg.vendors:
        return VerbResult(
            "ERROR: no vendors recorded. Run `goalie cli init <vendor>` first.\n"
            f"  Known vendors: {', '.join(ALL_VENDORS)}\n",
            exit_code=EXIT_BAD_REQUEST, stderr=True,
        )

    for v in vendors:
        if v not in ALL_VENDORS:
            return VerbResult(
                f"ERROR: unknown vendor {v!r}. Known vendors: {', '.join(ALL_VENDORS)}\n",
                exit_code=EXIT_BAD_REQUEST, stderr=True,
            )

    effective = list(dict.fromkeys([*cfg.vendors, *vendors]))  # merge, preserve order, dedupe

    lines: list[str] = []

    if force:
        skill_paths = scaffold_skills(cp_dir, force=True)
        lines.append("Skills reset from bundled templates:")
        for p in skill_paths:
            lines.append(f"  ~ {p}")
        lines.append("")

    goalie_md = render_goalie_md(cp_dir, cfg.target_repo)
    rendered = render_vendor_files(cp_dir, cfg.target_repo, effective)
    lines.append("Vendor files written:")
    lines.append(f"  + {goalie_md}")
    for p in rendered:
        lines.append(f"  + {p}")

    new_vendors = [v for v in vendors if v not in cfg.vendors]
    if new_vendors:
        lines.append("")
        lines.append(vendor_instructions(new_vendors))

    cfg.vendors = effective
    cfg.save()

    return VerbResult("\n".join(lines) + "\n", exit_code=EXIT_OK)
