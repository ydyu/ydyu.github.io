"""`goalie split <id> "<child>" ...` — break a node into children."""
from __future__ import annotations

from pathlib import Path
from typing import Optional

from . import VerbResult, EXIT_OK, EXIT_BAD_REQUEST
from ..config import resolve_control_plane
from ..staging import StagingError, install_staged_files
from ..store import Status, create_child, locked_node, set_status
from ..transitions import LEGAL_TRANSITIONS


def run(cwd: Path, ident: str, subs: list[str], *, cp_override: Optional[str] = None) -> VerbResult:
    if not subs:
        return VerbResult(
            "ERROR: split requires at least one child title.\n",
            exit_code=EXIT_BAD_REQUEST, stderr=True,
        )
    cp = resolve_control_plane(cwd, override=cp_override)

    # Install any staged files for parent (idempotent; missing cwd files are a no-op).
    # Also enforces REQUIRED_FILES["split"] = ("verify.md",).
    try:
        staging_result = install_staged_files(cp, ident, cwd, "split")
    except StagingError as e:
        return VerbResult(str(e), exit_code=EXIT_BAD_REQUEST, stderr=True)

    warnings = ("\n".join(staging_result.warnings) + "\n") if staging_result.warnings else ""

    with locked_node(cp, ident) as parent:
        if LEGAL_TRANSITIONS.get(("split", parent.status)) is None:
            return VerbResult(
                f"ERROR: cannot split `{parent.short_id}` — status is `{parent.status.value}`. "
                "Only unplanned, pending, or rejected nodes can be split.\n",
                exit_code=EXIT_BAD_REQUEST, stderr=True,
            )
        created = [create_child(cp, parent, title) for title in subs]
        set_status(parent, Status.pending)

    lines = [f"Split `{parent.short_id}` ({parent.title}) → {len(created)} children:"]
    for c in created:
        lines.append(f"  - `{c.short_id}`  {c.title}")
    lines.append("\nParent status: pending.")
    return VerbResult(f"{warnings}" + "\n".join(lines) + "\n", exit_code=EXIT_OK)
