"""`goalie plan [<id>]` — leaf finalize: install staged files and flip unplanned→pending.

Agent writes goalie_task_<id>.md + goalie_verify_<id>.md (and optionally
goalie_goal_<id>.md) in cwd (the target repo).  This verb resolves the
node, installs them, and transitions to pending when both task and verify
are present.  A goal-only staging turn installs the body without flipping.

Replan mode: if called with an explicit <id> on a pending or rejected node
and no staging files are present in cwd, the existing plan files are
restored to cwd for editing. Re-run after editing to install.
"""
from __future__ import annotations

from pathlib import Path
from typing import Optional

from . import VerbResult, EXIT_OK, EXIT_BAD_REQUEST
from ..config import resolve_control_plane
from ..staging import StagingError, install_staged_files
from ..store import Status, find_by_id
from ..transitions import transition_under_lock


def _restore_plan_files(cwd: Path, node) -> list[str]:
    """Dump existing plan files from node dir to cwd. Returns list of parts restored."""
    restored: list[str] = []
    if node.task_path.exists() and node.task_path.read_text().strip():
        (cwd / f"goalie_task_{node.id}.md").write_text(node.task_path.read_text())
        restored.append("task")
    if node.verify_path.exists() and node.verify_path.read_text().strip():
        (cwd / f"goalie_verify_{node.id}.md").write_text(node.verify_path.read_text())
        restored.append("verify")
    if node.body.strip():
        (cwd / f"goalie_goal_{node.id}.md").write_text(node.body.strip() + "\n")
        restored.append("goal")
    return restored


def run(cwd: Path, ident: Optional[str] = None, *, cp_override: Optional[str] = None) -> VerbResult:
    cp = resolve_control_plane(cwd, override=cp_override)

    # Replan mode: pending/rejected node, explicit id, no staging files in cwd
    if ident is not None:
        node = find_by_id(cp, ident)
        if node.status in (Status.pending, Status.rejected):
            has_staging = (
                (cwd / f"goalie_task_{node.id}.md").exists() or
                (cwd / f"goalie_verify_{node.id}.md").exists() or
                (cwd / f"goalie_goal_{node.id}.md").exists()
            )
            if not has_staging:
                restored = _restore_plan_files(cwd, node)
                parts = " + ".join(restored) if restored else "(no plan files in control plane)"
                return VerbResult(
                    f"`{node.short_id}` {parts} restored to cwd — edit, then re-run `goalie plan {node.short_id}`.\n",
                    exit_code=EXIT_OK,
                )

    try:
        result = install_staged_files(cp, ident, cwd, "plan")
    except StagingError as e:
        return VerbResult(str(e), exit_code=EXIT_BAD_REQUEST, stderr=True)

    node = result.node
    warnings = ("\n".join(result.warnings) + "\n") if result.warnings else ""

    # Flip to pending if node is unplanned and task + verify are now present
    flipped = False
    if node.status == Status.unplanned:
        has_task = node.task_path.exists() and node.task_path.read_text().strip()
        has_verify = node.verify_path.exists() and node.verify_path.read_text().strip()
        if has_task and has_verify:
            try:
                node, _ = transition_under_lock(cp, node.id, "plan")
                flipped = True
            except ValueError:
                pass

    written = " + ".join(result.parts_written) if result.parts_written else "(no new files)"
    suffix = " → pending." if flipped else "."
    return VerbResult(f"{warnings}`{node.short_id}` {written}{suffix}\n", exit_code=EXIT_OK)
