"""`goalie plan [<id>]` — leaf finalize: install staged files and flip unplanned→pending.

Agent writes goalie_task_<id>.md + goalie_verify_<id>.md (and optionally
goalie_goal_<id>.md) in cwd (the target repo).  This verb resolves the
node, installs them, and transitions to pending when both task and verify
are present.  A goal-only staging turn installs the body without flipping.
"""
from __future__ import annotations

from pathlib import Path
from typing import Optional

from . import VerbResult, EXIT_OK, EXIT_BAD_REQUEST
from ..config import resolve_control_plane
from ..staging import StagingError, install_staged_files
from ..store import Status
from ..transitions import transition_under_lock


def run(cwd: Path, ident: Optional[str] = None, *, cp_override: Optional[str] = None) -> VerbResult:
    cp = resolve_control_plane(cwd, override=cp_override)

    try:
        result = install_staged_files(cp, ident, cwd, "plan")
    except StagingError as e:
        return VerbResult(str(e), exit_code=EXIT_BAD_REQUEST, stderr=True)

    node = result.node
    warnings = ("\n".join(result.warnings) + "\n") if result.warnings else ""

    # Flip to pending if node is unplanned and task + verify are now present
    flipped = False
    if node.status == Status.unplanned:
        has_task = node.task_path.exists() and node.task_path.read_text().strip()
        has_verify = node.verify_path.exists() and node.verify_path.read_text().strip()
        if has_task and has_verify:
            try:
                node, _ = transition_under_lock(cp, node.id, "plan")
                flipped = True
            except ValueError:
                pass

    written = " + ".join(result.parts_written) if result.parts_written else "(no new files)"
    suffix = " → pending." if flipped else "."
    return VerbResult(f"{warnings}`{node.short_id}` {written}{suffix}\n", exit_code=EXIT_OK)
