"""`goalie status` — counts by status."""
from __future__ import annotations

from collections import Counter
from pathlib import Path

from typing import Optional

from . import VerbResult, EXIT_OK
from ..config import resolve_control_plane
from ..store import iter_tree, load_tree


def run(cwd: Path, *, cp_override: Optional[str] = None) -> VerbResult:
    cp = resolve_control_plane(cwd, override=cp_override)
    root = load_tree(cp)
    counts = Counter(n.status.value for n in iter_tree(root))
    lines = [f"Root: {root.title} (`{root.short_id}`)", "", "| status | count |", "|---|---|"]
    for k in sorted(counts):
        lines.append(f"| {k} | {counts[k]} |")
    return VerbResult("\n".join(lines) + "\n", exit_code=EXIT_OK)
