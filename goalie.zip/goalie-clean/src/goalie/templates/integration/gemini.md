## Wire goalie into Gemini CLI

Add this line to your `GEMINI.md` so Gemini imports the goalie context automatically:

```
@./GOALIE.md
```

If `GEMINI.md` doesn't exist yet, create it with just that line.
