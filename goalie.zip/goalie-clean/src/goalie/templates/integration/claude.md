## Wire goalie into Claude Code

Add this line to your `CLAUDE.md` so Claude imports the goalie context automatically:

```
@GOALIE.md
```

If `CLAUDE.md` doesn't exist yet, create it with just that line.

The goalie agent is installed at `.claude/agents/goalie.md` — Claude Code will offer it via the `/agents` picker and may delegate matching tasks to it automatically.
