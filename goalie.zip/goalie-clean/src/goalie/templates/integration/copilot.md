## Wire goalie into GitHub Copilot

**`.github/copilot-instructions.md`** — add this line so Copilot loads the goalie context:

```
See [GOALIE.md](../GOALIE.md) for the goalie multi-agent workflow.
```

If the file doesn't exist yet, create it with just that line.

**`AGENTS.md`** — add an entry so the goalie agent appears in `/agent` selection:

```markdown
## Goalie agent

- **goalie** — Goalie workflow agent; tell it to act as planner, solver, or reviewer — switchable at any time during the chat. See `.github/agents/goalie.md`.
  - **planner** — Splits goals into tasks and produces verify rubrics.
  - **solver** — Executes leaf goals and submits for review.
  - **reviewer** — Verifies submitted work against acceptance rubrics.
```

If `AGENTS.md` doesn't exist yet, create it with the block above (you may also add a header such as `# Agents`).
