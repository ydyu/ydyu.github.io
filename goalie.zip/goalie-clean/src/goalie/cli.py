"""Typer dispatcher for goalie v3."""
from __future__ import annotations

import functools
import sys
from pathlib import Path
from typing import Optional

import typer

from .store import LockContention
from .verbs import (
    EXIT_BAD_REQUEST, EXIT_FATAL, EXIT_LOCK_CONTENTION, VerbResult,
    approve as approve_verb,
    doctor as doctor_verb,
    done as done_verb,
    init as init_verb,
    next as next_verb,
    plan as plan_verb,
    reject as reject_verb,
    show as show_verb,
    split as split_verb,
    status as status_verb,
    tree as tree_verb,
)
from .verbs.admin.set_status import run as _admin_set_status
from .verbs.admin.rm import run as _admin_rm
from .verbs.admin.reparent import run as _admin_reparent
from .verbs import cli as cli_verb
from .render_skills import ALL_VENDORS

app = typer.Typer(
    add_completion=False,
    help="Goalie — control-plane CLI for multi-agent recursive work.",
    no_args_is_help=True,
)


def _emit(result: VerbResult) -> None:
    stream = sys.stderr if result.stderr else sys.stdout
    stream.write(result.text)
    stream.flush()
    raise typer.Exit(code=result.exit_code)


def _guard(fn):
    @functools.wraps(fn)
    def wrapper(*args, **kwargs):
        try:
            return fn(*args, **kwargs)
        except typer.Exit:
            raise
        except LockContention as e:
            _emit(VerbResult(f"ERROR: {e}\n", exit_code=EXIT_LOCK_CONTENTION, stderr=True))
        except Exception as e:
            _emit(VerbResult(
                f"FATAL: {type(e).__name__}: {e}\n",
                exit_code=EXIT_FATAL, stderr=True,
            ))
    return wrapper


def _cwd() -> Path:
    return Path.cwd()


_CP_HELP = "Control-plane path (overrides GOALIE_CP env var and walk-up)."

_PLANNER = "Planner"
_SOLVER = "Solver"
_REVIEWER = "Reviewer"
_READONLY = "Read-only"


@app.command()
@_guard
def init(
    goal: str = typer.Argument(..., help="Initial root-goal description."),
    control_plane: bool = typer.Option(False, "--control-plane", help="Initialize .goalie/ outside the target repo."),
    target: Optional[str] = typer.Option(None, "--target", help="Path to the target repo. Required with --control-plane."),
    cli: Optional[str] = typer.Option(None, "--cli", help=f"Comma-list of vendors to wire: {','.join(ALL_VENDORS)} or 'all'."),
):
    """Create the control plane and the initial root goal."""
    if cli and cli.strip().lower() == "all":
        vendors = list(ALL_VENDORS)
    else:
        vendors = [v.strip() for v in cli.split(",")] if cli else []
    _emit(init_verb.run(
        _cwd(), goal,
        control_plane=control_plane,
        target=target,
        cli_vendors=vendors or None,
    ))


@app.command(rich_help_panel=_READONLY)
@_guard
def next(
    ident: Optional[str] = typer.Argument(None, help="Node id (or prefix). Auto-detects if omitted."),
    role: str = typer.Option(..., "--role", help="Role to pull work for (planner/solver/reviewer/...)."),
    cp: Optional[str] = typer.Option(None, "--cp", help=_CP_HELP),
):
    """Print the next task for a role, or target a specific task."""
    _emit(next_verb.run(_cwd(), role, ident=ident, cp_override=cp))


@app.command(rich_help_panel=_PLANNER)
@_guard
def plan(
    ident: Optional[str] = typer.Argument(None, help="Node id (or prefix). Auto-detected if omitted."),
    cp: Optional[str] = typer.Option(None, "--cp", help=_CP_HELP),
):
    """Install staged goalie_*.md files and flip unplanned→pending when ready."""
    _emit(plan_verb.run(_cwd(), ident, cp_override=cp))


@app.command(rich_help_panel=_PLANNER)
@_guard
def split(
    ident: str = typer.Argument(..., help="Node id (or prefix)."),
    children: list[str] = typer.Argument(..., help="Child titles."),
    cp: Optional[str] = typer.Option(None, "--cp", help=_CP_HELP),
):
    """Decompose a node into children. Requires verify.md on parent."""
    _emit(split_verb.run(_cwd(), ident, children, cp_override=cp))


@app.command(rich_help_panel=_SOLVER)
@_guard
def done(
    ident: str = typer.Argument(..., help="Node id (or prefix)."),
    cp: Optional[str] = typer.Option(None, "--cp", help=_CP_HELP),
):
    """Submit solver work for review: pending → needs_review."""
    _emit(done_verb.run(_cwd(), ident, cp_override=cp))


@app.command(rich_help_panel=_REVIEWER)
@_guard
def approve(
    ident: str = typer.Argument(..., help="Node id (or prefix)."),
    cp: Optional[str] = typer.Option(None, "--cp", help=_CP_HELP),
):
    """Accept reviewed work: needs_review → done. Requires clean working tree."""
    _emit(approve_verb.run(_cwd(), ident, cp_override=cp))


@app.command(rich_help_panel=_REVIEWER)
@_guard
def reject(
    ident: str = typer.Argument(..., help="Node id (or prefix)."),
    reason: str = typer.Argument(..., help="Critique / rejection reason (non-empty)."),
    cp: Optional[str] = typer.Option(None, "--cp", help=_CP_HELP),
):
    """Reject reviewed work with a critique: needs_review → rejected."""
    _emit(reject_verb.run(_cwd(), ident, reason, cp_override=cp))


@app.command(rich_help_panel=_READONLY)
@_guard
def show(
    ident: str = typer.Argument(..., help="Node id (or prefix)."),
    cp: Optional[str] = typer.Option(None, "--cp", help=_CP_HELP),
):
    """Print goal/task/verify/Q&A for a node (read-only)."""
    _emit(show_verb.run(_cwd(), ident, cp_override=cp))


@app.command()
@_guard
def doctor(
    prune: bool = typer.Option(False, "--prune", help="Delete orphan node directories."),
    cp: Optional[str] = typer.Option(None, "--cp", help=_CP_HELP),
):
    """Report (or prune) orphan dirs in the control plane nodes tree."""
    _emit(doctor_verb.run(_cwd(), prune=prune, cp_override=cp))


@app.command(rich_help_panel=_READONLY)
@_guard
def tree(
    cp: Optional[str] = typer.Option(None, "--cp", help=_CP_HELP),
):
    """Print the goal tree."""
    _emit(tree_verb.run(_cwd(), cp_override=cp))


@app.command(rich_help_panel=_READONLY)
@_guard
def status(
    cp: Optional[str] = typer.Option(None, "--cp", help=_CP_HELP),
):
    """Print status counts."""
    _emit(status_verb.run(_cwd(), cp_override=cp))


admin_app = typer.Typer(
    hidden=True,
    help="[TEMPORARY SCAFFOLDING] State-recovery verbs. Not for normal use.",
    no_args_is_help=True,
)
app.add_typer(admin_app, name="admin")


@admin_app.command("set-status")
@_guard
def admin_set_status(
    ident: str = typer.Argument(..., help="Node id (or prefix)."),
    status: str = typer.Argument(..., help="Target status value."),
    cp: Optional[str] = typer.Option(None, "--cp", help=_CP_HELP),
):
    """[ADMIN] Force a node to any status, bypassing state-machine guards."""
    _emit(_admin_set_status(_cwd(), ident, status, cp_override=cp))


@admin_app.command("rm")
@_guard
def admin_rm(
    ident: str = typer.Argument(..., help="Node id (or prefix)."),
    recursive: bool = typer.Option(False, "--recursive", help="Also delete all descendants."),
    cp: Optional[str] = typer.Option(None, "--cp", help=_CP_HELP),
):
    """[ADMIN] Delete a node (and optionally its subtree)."""
    _emit(_admin_rm(_cwd(), ident, recursive=recursive, cp_override=cp))


@admin_app.command("reparent")
@_guard
def admin_reparent(
    ident: str = typer.Argument(..., help="Node id (or prefix)."),
    new_parent: str = typer.Argument(..., help="New parent node id (or prefix)."),
    cp: Optional[str] = typer.Option(None, "--cp", help=_CP_HELP),
):
    """[ADMIN] Change a node's parent (cycle-safe)."""
    _emit(_admin_reparent(_cwd(), ident, new_parent, cp_override=cp))


cli_app = typer.Typer(
    help="Manage vendor CLI integrations (render vendor files, wire new vendors).",
    no_args_is_help=True,
)
app.add_typer(cli_app, name="cli")


@cli_app.command("init")
@_guard
def cli_init(
    vendors: Optional[list[str]] = typer.Argument(
        None,
        help=f"Vendors to wire: {', '.join(ALL_VENDORS)}, or omit to re-render all wired vendors.",
    ),
    force: bool = typer.Option(False, "--force", help="Overwrite .goalie/skills/*.md from bundled templates before rendering."),
    cp: Optional[str] = typer.Option(None, "--cp", help=_CP_HELP),
):
    """Render vendor files from .goalie/skills/. Wires new vendors into config."""
    resolved: list[str] = []
    for v in (vendors or []):
        if v.lower() == "all":
            resolved = list(ALL_VENDORS)
            break
        resolved.append(v)
    _emit(cli_verb.init_(_cwd(), resolved, force=force, cp_override=cp))


def main() -> None:
    app()


if __name__ == "__main__":
    main()
