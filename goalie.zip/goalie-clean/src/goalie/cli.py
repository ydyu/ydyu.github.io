"""Argparse dispatcher for goalie."""
from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Optional

from .store import LockContention
from .verbs import (
    EXIT_FATAL, EXIT_LOCK_CONTENTION, VerbResult,
    approve as approve_verb,
    doctor as doctor_verb,
    done as done_verb,
    init as init_verb,
    next as next_verb,
    plan as plan_verb,
    reject as reject_verb,
    show as show_verb,
    split as split_verb,
    status as status_verb,
    tree as tree_verb,
)
from .verbs.admin.set_status import run as _admin_set_status
from .verbs.admin.rm import run as _admin_rm
from .verbs.admin.reparent import run as _admin_reparent
from .verbs import cli as cli_verb
from .render_skills import ALL_VENDORS


def _emit(result: VerbResult) -> None:
    stream = sys.stderr if result.stderr else sys.stdout
    stream.write(result.text)
    stream.flush()
    sys.exit(result.exit_code)


def _guard(fn):
    def wrapper(args: argparse.Namespace) -> None:
        try:
            fn(args)
        except SystemExit:
            raise
        except LockContention as e:
            _emit(VerbResult(f"ERROR: {e}\n", exit_code=EXIT_LOCK_CONTENTION, stderr=True))
        except Exception as e:
            _emit(VerbResult(
                f"FATAL: {type(e).__name__}: {e}\n",
                exit_code=EXIT_FATAL, stderr=True,
            ))
    return wrapper


def _cwd() -> Path:
    return Path.cwd()


def _add_cp(p: argparse.ArgumentParser) -> None:
    p.add_argument("--cp", help="Control-plane path (overrides GOALIE_CP env var and walk-up).")


# ---------- command handlers ----------

@_guard
def _cmd_init(args: argparse.Namespace) -> None:
    vendors_raw: Optional[str] = args.cli_vendors
    if vendors_raw and vendors_raw.strip().lower() == "all":
        vendors = list(ALL_VENDORS)
    else:
        vendors = [v.strip() for v in vendors_raw.split(",")] if vendors_raw else []
    _emit(init_verb.run(
        _cwd(), args.goal,
        control_plane=args.control_plane,
        target=args.target,
        cli_vendors=vendors or None,
    ))


@_guard
def _cmd_next(args: argparse.Namespace) -> None:
    _emit(next_verb.run(_cwd(), args.role, ident=args.ident, cp_override=args.cp))


@_guard
def _cmd_plan(args: argparse.Namespace) -> None:
    _emit(plan_verb.run(_cwd(), args.ident, cp_override=args.cp))


@_guard
def _cmd_split(args: argparse.Namespace) -> None:
    _emit(split_verb.run(_cwd(), args.ident, args.children, cp_override=args.cp))


@_guard
def _cmd_done(args: argparse.Namespace) -> None:
    _emit(done_verb.run(_cwd(), args.ident, cp_override=args.cp))


@_guard
def _cmd_approve(args: argparse.Namespace) -> None:
    _emit(approve_verb.run(_cwd(), args.ident, cp_override=args.cp))


@_guard
def _cmd_reject(args: argparse.Namespace) -> None:
    _emit(reject_verb.run(_cwd(), args.ident, args.reason, cp_override=args.cp))


@_guard
def _cmd_show(args: argparse.Namespace) -> None:
    _emit(show_verb.run(_cwd(), args.ident, cp_override=args.cp))


@_guard
def _cmd_doctor(args: argparse.Namespace) -> None:
    _emit(doctor_verb.run(_cwd(), prune=args.prune, cp_override=args.cp))


@_guard
def _cmd_tree(args: argparse.Namespace) -> None:
    _emit(tree_verb.run(_cwd(), cp_override=args.cp))


@_guard
def _cmd_status(args: argparse.Namespace) -> None:
    _emit(status_verb.run(_cwd(), cp_override=args.cp))


@_guard
def _cmd_admin_set_status(args: argparse.Namespace) -> None:
    _emit(_admin_set_status(_cwd(), args.ident, args.status_value, cp_override=args.cp))


@_guard
def _cmd_admin_rm(args: argparse.Namespace) -> None:
    _emit(_admin_rm(_cwd(), args.ident, recursive=args.recursive, cp_override=args.cp))


@_guard
def _cmd_admin_reparent(args: argparse.Namespace) -> None:
    _emit(_admin_reparent(_cwd(), args.ident, args.new_parent, cp_override=args.cp))


@_guard
def _cmd_cli_init(args: argparse.Namespace) -> None:
    resolved: list[str] = []
    for v in (args.vendors or []):
        if v.lower() == "all":
            resolved = list(ALL_VENDORS)
            break
        resolved.append(v)
    _emit(cli_verb.init_(_cwd(), resolved, force=args.force, cp_override=args.cp))


# ---------- parser ----------

def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="goalie",
        description="Goalie — control-plane CLI for multi-agent recursive work.",
    )
    sub = p.add_subparsers(dest="cmd", required=True, metavar="<command>")

    # init
    p_init = sub.add_parser("init", help="Create the control plane and the initial root goal.")
    p_init.add_argument("goal", help="Initial root-goal description.")
    p_init.add_argument("--control-plane", action="store_true", help="Initialize .goalie/ outside the target repo.")
    p_init.add_argument("--target", help="Path to the target repo. Required with --control-plane.")
    p_init.add_argument("--cli", dest="cli_vendors", metavar="VENDORS",
                        help=f"Comma-list of vendors to wire: {','.join(ALL_VENDORS)} or 'all'.")
    p_init.set_defaults(func=_cmd_init)

    # next
    p_next = sub.add_parser("next", help="Print the next task for a role, or target a specific task.")
    p_next.add_argument("ident", nargs="?", default=None, help="Node id (or prefix). Auto-detects if omitted.")
    p_next.add_argument("--role", required=True, help="Role to pull work for (planner/solver/reviewer/...).")
    _add_cp(p_next)
    p_next.set_defaults(func=_cmd_next)

    # plan
    p_plan = sub.add_parser("plan", help="[Planner] Install staged goalie_*.md files and flip unplanned→pending when ready.")
    p_plan.add_argument("ident", nargs="?", default=None, help="Node id (or prefix). Auto-detected if omitted.")
    _add_cp(p_plan)
    p_plan.set_defaults(func=_cmd_plan)

    # split
    p_split = sub.add_parser("split", help="[Planner] Decompose a node into children. Requires verify.md on parent.")
    p_split.add_argument("ident", help="Node id (or prefix).")
    p_split.add_argument("children", nargs="+", help="Child titles.")
    _add_cp(p_split)
    p_split.set_defaults(func=_cmd_split)

    # done
    p_done = sub.add_parser("done", help="[Solver] Submit solver work for review: pending → needs_review.")
    p_done.add_argument("ident", help="Node id (or prefix).")
    _add_cp(p_done)
    p_done.set_defaults(func=_cmd_done)

    # approve
    p_approve = sub.add_parser("approve", help="[Reviewer] Accept reviewed work: needs_review → done.")
    p_approve.add_argument("ident", help="Node id (or prefix).")
    _add_cp(p_approve)
    p_approve.set_defaults(func=_cmd_approve)

    # reject
    p_reject = sub.add_parser("reject", help="[Reviewer] Reject reviewed work with a critique: needs_review → rejected.")
    p_reject.add_argument("ident", help="Node id (or prefix).")
    p_reject.add_argument("reason", help="Critique / rejection reason (non-empty).")
    _add_cp(p_reject)
    p_reject.set_defaults(func=_cmd_reject)

    # show
    p_show = sub.add_parser("show", help="Print goal/task/verify/Q&A for a node (read-only).")
    p_show.add_argument("ident", help="Node id (or prefix).")
    _add_cp(p_show)
    p_show.set_defaults(func=_cmd_show)

    # doctor
    p_doctor = sub.add_parser("doctor", help="Report (or prune) orphan dirs in the control plane nodes tree.")
    p_doctor.add_argument("--prune", action="store_true", help="Delete orphan node directories.")
    _add_cp(p_doctor)
    p_doctor.set_defaults(func=_cmd_doctor)

    # tree
    p_tree = sub.add_parser("tree", help="Print the goal tree.")
    _add_cp(p_tree)
    p_tree.set_defaults(func=_cmd_tree)

    # status
    p_status = sub.add_parser("status", help="Print status counts.")
    _add_cp(p_status)
    p_status.set_defaults(func=_cmd_status)

    # admin (subgroup)
    p_admin = sub.add_parser("admin", help=argparse.SUPPRESS)
    sub._choices_actions.pop()  # hide from --help listing; still reachable as `goalie admin`
    admin_sub = p_admin.add_subparsers(dest="admin_cmd", required=True, metavar="<subcommand>")

    p_as = admin_sub.add_parser("set-status", help="Force a node to any status, bypassing state-machine guards.")
    p_as.add_argument("ident", help="Node id (or prefix).")
    p_as.add_argument("status_value", metavar="status", help="Target status value.")
    _add_cp(p_as)
    p_as.set_defaults(func=_cmd_admin_set_status)

    p_arm = admin_sub.add_parser("rm", help="Delete a node (and optionally its subtree).")
    p_arm.add_argument("ident", help="Node id (or prefix).")
    p_arm.add_argument("--recursive", action="store_true", help="Also delete all descendants.")
    _add_cp(p_arm)
    p_arm.set_defaults(func=_cmd_admin_rm)

    p_arp = admin_sub.add_parser("reparent", help="Change a node's parent (cycle-safe).")
    p_arp.add_argument("ident", help="Node id (or prefix).")
    p_arp.add_argument("new_parent", help="New parent node id (or prefix).")
    _add_cp(p_arp)
    p_arp.set_defaults(func=_cmd_admin_reparent)

    # cli (subgroup)
    p_cli = sub.add_parser("cli", help="Manage vendor CLI integrations.")
    cli_sub = p_cli.add_subparsers(dest="cli_cmd", required=True, metavar="<subcommand>")

    p_ci = cli_sub.add_parser("init", help="Render vendor files from .goalie/skills/. Wires new vendors into config.")
    p_ci.add_argument("vendors", nargs="*",
                      help=f"Vendors to wire: {', '.join(ALL_VENDORS)}, or omit to re-render all wired vendors.")
    p_ci.add_argument("--force", action="store_true", help="Overwrite .goalie/skills/*.md from bundled templates before rendering.")
    _add_cp(p_ci)
    p_ci.set_defaults(func=_cmd_cli_init)

    return p


def main() -> None:
    args = build_parser().parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
