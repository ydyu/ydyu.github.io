"""CWD staging file installer shared by plan and split verbs."""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from .store import Node, Status, find_by_id, index_lock, write_node
from .transitions import REQUIRED_FILES

_TASK_RE = re.compile(r"^goalie_task_([A-Za-z0-9]+)\.md$")
_VERIFY_RE = re.compile(r"^goalie_verify_([A-Za-z0-9]+)\.md$")
_GOAL_RE = re.compile(r"^goalie_goal_([A-Za-z0-9]+)\.md$")


class StagingError(ValueError):
    """User-visible error from install_staged_files."""


@dataclass
class StagingResult:
    node: Node
    parts_written: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)


def _scan(cwd: Path) -> dict[str, set[str]]:
    found: dict[str, set[str]] = {}
    for f in cwd.iterdir():
        if not f.is_file():
            continue
        for pat, kind in ((_TASK_RE, "task"), (_VERIFY_RE, "verify"), (_GOAL_RE, "goal")):
            m = pat.match(f.name)
            if m:
                found.setdefault(m.group(1), set()).add(kind)
                break
    return found


def _has_done_descendant(node: Node) -> bool:
    return any(c.status == Status.done or _has_done_descendant(c) for c in node.children)


def _check_required(node: Node, verb: str) -> None:
    """Raise StagingError if REQUIRED_FILES invariant not met on node after install."""
    for fname in REQUIRED_FILES.get(verb, ()):
        fpath = node.dir / fname
        if not fpath.exists() or not fpath.read_text().strip():
            key = fname.replace(".md", "")
            raise StagingError(
                f"ERROR: `{node.short_id}` missing `{fname}` for `{verb}`.\n"
                f"Write goalie_{key}_{node.id}.md in cwd and re-run.\n"
            )


def _stale_lines(stale_ids: list[str], staging: dict[str, set[str]]) -> list[str]:
    if not stale_ids:
        return []
    lines = ["WARNING: stale staging files for other IDs (clean up manually):"]
    for sid in stale_ids:
        for kind in sorted(staging[sid]):
            lines.append(f"  goalie_{kind}_{sid}.md")
    return ["\n".join(lines)]


def install_staged_files(
    cp: Path,
    node_id: Optional[str],
    cwd: Path,
    verb: str,
) -> StagingResult:
    """Read staging files from cwd, install into node dir. Raise StagingError on problems."""
    staging = _scan(cwd)
    stageable = {
        id_ for id_, parts in staging.items()
        if "goal" in parts or "verify" in parts or "task" in parts
    }

    if node_id is None:
        if not stageable:
            raise StagingError(
                "No staging file(s) found in cwd.\n"
                "Write goalie_goal_<node_id>.md, goalie_verify_<node_id>.md "
                "(and optionally goalie_task_<node_id>.md), then re-run.\n"
            )
        if len(stageable) > 1:
            raise StagingError(
                "Multiple staging IDs found — pass an explicit id:\n"
                + "".join(f"  {id_}\n" for id_ in sorted(stageable))
            )
        file_id = next(iter(stageable))
        node = find_by_id(cp, file_id)
    else:
        node = find_by_id(cp, node_id)
        file_id = node.id

    file_parts = staging.get(file_id, set())
    has_task = "task" in file_parts
    has_verify = "verify" in file_parts
    has_goal = "goal" in file_parts

    stale = sorted(id_ for id_ in staging if id_ != file_id)
    warnings = _stale_lines(stale, staging)

    if not (has_task or has_verify or has_goal):
        # No staging files for this node — check REQUIRED_FILES against existing files
        _check_required(node, verb)
        return StagingResult(node=node, parts_written=[], warnings=warnings)

    task_file = cwd / f"goalie_task_{file_id}.md"
    verify_file = cwd / f"goalie_verify_{file_id}.md"
    goal_file = cwd / f"goalie_goal_{file_id}.md"

    # Read and validate before acquiring lock
    verify_content = ""
    if has_verify:
        verify_content = verify_file.read_text().strip()
        if not verify_content:
            raise StagingError(f"ERROR: goalie_verify_{file_id}.md is empty.\n")

    task_content = ""
    if has_task:
        task_content = task_file.read_text().strip()
        if not task_content:
            raise StagingError(f"ERROR: goalie_task_{file_id}.md is empty.\n")

    goal_content = ""
    if has_goal:
        goal_content = goal_file.read_text().strip()
        if not goal_content:
            raise StagingError(f"ERROR: goalie_goal_{file_id}.md is empty.\n")

    with index_lock(cp):
        node = find_by_id(cp, file_id)  # fresh read inside lock

        if has_verify and node.verify_path.exists() and node.verify_path.read_text().strip():
            if _has_done_descendant(node):
                warnings.append(
                    f"WARNING: overwriting verify.md on `{node.short_id}` "
                    "which has done descendants."
                )

        if has_task and node.task_path.exists() and node.task_path.read_text().strip():
            if _has_done_descendant(node):
                warnings.append(
                    f"WARNING: overwriting task.md on `{node.short_id}` "
                    "which has done descendants."
                )

        if has_goal:
            node.body = goal_content
            write_node(node)
        if has_task:
            node.task_path.write_text(task_content + "\n")
        if has_verify:
            node.verify_path.write_text(verify_content + "\n")

        _check_required(node, verb)

        # Remove staging files inside the lock for atomicity
        if has_goal:
            goal_file.unlink()
        if has_task:
            task_file.unlink()
        if has_verify:
            verify_file.unlink()

    parts_written: list[str] = []
    if has_goal:
        parts_written.append("goal")
    if has_task and has_verify:
        parts_written.append("task + verify")
    elif has_task:
        parts_written.append("task")
    elif has_verify:
        parts_written.append("verify")

    return StagingResult(node=node, parts_written=parts_written, warnings=warnings)
