# Minimal PEP 517 build backend — stdlib only, zero external deps.
import base64
import hashlib
import pathlib
import re
import zipfile

ROOT = pathlib.Path(__file__).parent
SRC = ROOT / "src"

_SKIP_PARTS = {"__pycache__", ".git", "dist", "build", ".tox", ".mypy_cache"}


def _meta():
    text = (ROOT / "pyproject.toml").read_text()
    get = lambda key: re.search(rf'^{key}\s*=\s*"([^"]+)"', text, re.M).group(1)
    return {
        "name":           get("name"),
        "version":        get("version"),
        "description":    get("description"),
        "requires_python": get("requires-python"),
    }


def _tag(data: bytes) -> str:
    digest = hashlib.sha256(data).digest()
    return "sha256=" + base64.urlsafe_b64encode(digest).rstrip(b"=").decode()


def get_requires_for_build_wheel(config_settings=None):
    return []


def get_requires_for_build_editable(config_settings=None):
    return []


def get_requires_for_build_sdist(config_settings=None):
    return []


def build_wheel(wheel_directory, config_settings=None, metadata_directory=None):
    meta = _meta()
    safe_name = meta["name"].replace("-", "_")
    dist_info = f"{safe_name}-{meta['version']}.dist-info"
    wheel_name = f"{safe_name}-{meta['version']}-py3-none-any.whl"
    wheel_path = pathlib.Path(wheel_directory) / wheel_name

    records = []

    def add(whl, arcname, data):
        whl.writestr(arcname, data)
        records.append(f"{arcname},{_tag(data)},{len(data)}")

    with zipfile.ZipFile(wheel_path, "w", compression=zipfile.ZIP_DEFLATED) as whl:
        pkg_root = SRC / meta["name"]
        for p in sorted(pkg_root.rglob("*")):
            if p.is_dir() or _SKIP_PARTS & set(p.parts):
                continue
            arcname = meta["name"] + "/" + str(p.relative_to(pkg_root))
            add(whl, arcname, p.read_bytes())

        wheel_txt = (
            "Wheel-Version: 1.0\n"
            "Generator: goalie-build\n"
            "Root-Is-Purelib: true\n"
            "Tag: py3-none-any\n"
        )
        add(whl, f"{dist_info}/WHEEL", wheel_txt.encode())

        metadata_txt = (
            "Metadata-Version: 2.1\n"
            f"Name: {meta['name']}\n"
            f"Version: {meta['version']}\n"
            f"Summary: {meta['description']}\n"
            f"Requires-Python: {meta['requires_python']}\n"
        )
        add(whl, f"{dist_info}/METADATA", metadata_txt.encode())

        ep_txt = "[console_scripts]\ngoalie = goalie.cli:main\n"
        add(whl, f"{dist_info}/entry_points.txt", ep_txt.encode())

        records.append(f"{dist_info}/RECORD,,")
        whl.writestr(f"{dist_info}/RECORD", "\n".join(records).encode())

    return wheel_name


def build_editable(wheel_directory, config_settings=None, metadata_directory=None):
    meta = _meta()
    safe_name = meta["name"].replace("-", "_")
    dist_info = f"{safe_name}-{meta['version']}.dist-info"
    wheel_name = f"{safe_name}-{meta['version']}-py3-none-any.whl"
    wheel_path = pathlib.Path(wheel_directory) / wheel_name

    records = []

    def add(whl, arcname, data):
        whl.writestr(arcname, data)
        records.append(f"{arcname},{_tag(data)},{len(data)}")

    with zipfile.ZipFile(wheel_path, "w", compression=zipfile.ZIP_DEFLATED) as whl:
        pth_data = (str(SRC) + "\n").encode()
        add(whl, f"{safe_name}.pth", pth_data)

        wheel_txt = (
            "Wheel-Version: 1.0\n"
            "Generator: goalie-build\n"
            "Root-Is-Purelib: true\n"
            "Tag: py3-none-any\n"
        )
        add(whl, f"{dist_info}/WHEEL", wheel_txt.encode())

        metadata_txt = (
            "Metadata-Version: 2.1\n"
            f"Name: {meta['name']}\n"
            f"Version: {meta['version']}\n"
            f"Summary: {meta['description']}\n"
            f"Requires-Python: {meta['requires_python']}\n"
        )
        add(whl, f"{dist_info}/METADATA", metadata_txt.encode())

        ep_txt = "[console_scripts]\ngoalie = goalie.cli:main\n"
        add(whl, f"{dist_info}/entry_points.txt", ep_txt.encode())

        records.append(f"{dist_info}/RECORD,,")
        whl.writestr(f"{dist_info}/RECORD", "\n".join(records).encode())

    return wheel_name


def build_sdist(sdist_directory, config_settings=None):
    import tarfile

    meta = _meta()
    safe_name = meta["name"].replace("-", "_")
    prefix = f"{safe_name}-{meta['version']}"
    sdist_name = f"{prefix}.tar.gz"
    sdist_path = pathlib.Path(sdist_directory) / sdist_name

    with tarfile.open(sdist_path, "w:gz") as tar:
        for p in sorted(ROOT.rglob("*")):
            if p.is_dir() or _SKIP_PARTS & set(p.parts):
                continue
            tar.add(p, arcname=f"{prefix}/{p.relative_to(ROOT)}")

    return sdist_name
