"""Shared test helpers for goalie v3."""
from __future__ import annotations

import os
import re
import subprocess
import sys
from pathlib import Path

import pytest


def _goalie_argv() -> list[str]:
    return [sys.executable, "-m", "goalie.cli"]


def run(
    cwd: Path,
    *args: str,
    env: dict | None = None,
    check: bool = False,
) -> subprocess.CompletedProcess:
    e = os.environ.copy()
    e.pop("GOALIE_CP", None)  # prevent shell env from leaking into test subprocesses
    if env:
        e.update(env)
    r = subprocess.run(
        [*_goalie_argv(), *args],
        cwd=str(cwd),
        text=True,
        capture_output=True,
        env=e,
    )
    if check and r.returncode != 0:
        raise AssertionError(f"goalie {' '.join(args)} → {r.returncode}\nstdout:\n{r.stdout}\nstderr:\n{r.stderr}")
    return r


def parse_frontmatter(stdout: str) -> tuple[dict, str]:
    """Parse a `goalie next` document into (frontmatter, body)."""
    import yaml
    if not stdout.startswith("---"):
        raise AssertionError(f"Expected frontmatter, got:\n{stdout[:200]}")
    _, fm, body = stdout.split("---", 2)
    return yaml.safe_load(fm), body


def write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text)


def _find_node_dir(workspace: Path, node_id: str) -> Path:
    """Return the node dir whose goal.md declares node_id as its id: field."""
    nodes_root = workspace / ".goalie" / "nodes"
    pattern = re.compile(r'^\s*id:\s+' + re.escape(node_id), re.MULTILINE)
    return next(
        d for d in nodes_root.iterdir()
        if (d / "goal.md").exists() and pattern.search((d / "goal.md").read_text())
    )


def git_commit(target: Path, message: str, files: list[str] | None = None) -> str:
    """Stage files (all if omitted) and commit. Returns SHA."""
    import subprocess as _sp
    if files:
        for f in files:
            _sp.check_call(["git", "add", f], cwd=str(target))
    else:
        _sp.check_call(["git", "add", "-A"], cwd=str(target))
    _sp.check_call(["git", "commit", "-m", message], cwd=str(target))
    return _sp.check_output(["git", "rev-parse", "HEAD"], cwd=str(target), text=True).strip()


def git_log(target: Path, *args: str) -> str:
    return subprocess.check_output(
        ["git", "log", *args, "--pretty=format:%H%n%B%n--END--"],
        cwd=str(target), text=True,
    )


@pytest.fixture
def workspace(tmp_path: Path) -> Path:
    """A directory containing a `target/` subdir to be the target_repo
    and itself acting as the cwd where `.goalie/` lives (--control-plane mode)."""
    target = tmp_path / "target"
    target.mkdir()
    return tmp_path
