"""End-to-end lifecycle tests: init, plan/solve/approve, rollup, error cases."""
from __future__ import annotations

import re
import yaml
from pathlib import Path

from tests.conftest import _find_node_dir, git_commit, git_log, parse_frontmatter, run, write


TRIGGER_PHRASES = ("ignore previous", "now act as", "system:")


def _assert_no_triggers(text: str) -> None:
    lo = text.lower()
    for t in TRIGGER_PHRASES:
        assert t not in lo, f"trigger phrase {t!r} present in goalie output"


def test_full_multi_agent_flow(workspace: Path):
    target = workspace / "target"

    # ---- Phase 1: init ----
    r = run(workspace, "init", "Build a tiny calculator module",
            "--control-plane", "--target", "target", "--cli", "all",
            check=True)

    assert (target / "GOALIE.md").exists()
    assert not (target / "CLAUDE.md").exists()
    assert not (target / ".github" / "copilot-instructions.md").exists()
    assert not (target / "AGENTS.md").exists()
    assert not (target / "GEMINI.md").exists()

    assert (target / ".claude" / "commands" / "planner.md").exists()
    assert (target / ".claude" / "commands" / "solver.md").exists()
    assert (target / ".claude" / "agents" / "goalie.md").exists()
    assert (target / ".github" / "agents" / "goalie.md").exists()
    assert not (target / ".github" / "agents" / "goalie-planner.md").exists()
    assert not (target / ".github" / "agents" / "goalie-solver.md").exists()
    assert not (target / ".github" / "agents" / "goalie-reviewer.md").exists()
    assert (target / ".github" / "prompts" / "solver.prompt.md").exists()
    assert (target / ".gemini" / "commands" / "reviewer.toml").exists()
    assert (target / ".gemini" / "commands" / "solver.toml").exists()

    agent_text = (target / ".github" / "agents" / "goalie.md").read_text()
    assert "name: goalie" in agent_text

    claude_agent_text = (target / ".claude" / "agents" / "goalie.md").read_text()
    assert "name: goalie" in claude_agent_text

    assert "@GOALIE.md" in r.stdout
    assert "@./GOALIE.md" in r.stdout

    import yaml as _yaml
    cfg_data = _yaml.safe_load((workspace / ".goalie" / "config.yaml").read_text())
    assert set(cfg_data["vendors"]) == {"copilot", "claude", "gemini"}

    assert (workspace / ".goalie" / "skills" / "_base.md").exists()
    assert (workspace / ".goalie" / "skills" / "planner.md").exists()
    assert (workspace / ".goalie" / "skills" / "solver.md").exists()

    # ---- Scenario 1: planner pulls root, stages verify, splits ----
    r = run(workspace, "next", "--role", "planner", check=True)
    fm, body = parse_frontmatter(r.stdout)
    assert fm["role"] == "planner"
    assert fm["status"] == "unplanned"
    assert "## Task" in body and "## Acceptance" in body and "## Context" in body
    _assert_no_triggers(r.stdout)
    root_id = fm["node_id"]

    write(target / f"goalie_verify_{root_id}.md", "calculator module provides add and sub functions")
    r = run(target, "split", root_id, "Add add(a,b)", "Add sub(a,b)", check=True)
    assert "pending" in r.stdout

    r = run(workspace, "tree", check=True)
    assert "┬" in r.stdout
    assert "Add add" in r.stdout

    # ---- Scenario 2: planner plans first child via staging ----
    r = run(workspace, "next", "--role", "planner", check=True)
    fm, body = parse_frontmatter(r.stdout)
    child_id = fm["node_id"]
    assert fm["status"] == "unplanned"

    write(target / f"goalie_task_{child_id}.md", "Implement add(a,b) returning a+b in calc.py")
    write(target / f"goalie_verify_{child_id}.md", "calc.py defines add(a,b); add(2,3) == 5")
    r = run(target, "plan", child_id, check=True)
    assert "pending" in r.stdout

    # ---- Scenario 3: solver picks pending → submits ----
    r = run(workspace, "next", "--role", "solver", check=True)
    fm, body = parse_frontmatter(r.stdout)
    assert fm["node_id"] == child_id
    assert fm["status"] == "pending"
    assert "add(2,3)" in body
    _assert_no_triggers(r.stdout)

    write(target / "calc.py", "def add(a, b):\n    return 0  # bug\n")
    r = run(workspace, "done", child_id, check=True)
    assert "needs_review" in r.stdout

    # ---- Scenario 4: reviewer rejects ----
    r = run(workspace, "next", "--role", "reviewer", check=True)
    fm, _ = parse_frontmatter(r.stdout)
    assert fm["node_id"] == child_id
    assert fm["status"] == "needs_review"

    r = run(workspace, "reject", child_id, "add returns 0 instead of a+b", check=True)
    assert "rejected" in r.stdout

    # ---- Scenario 5: solver picks rejected; prior feedback included ----
    r = run(workspace, "next", "--role", "solver", check=True)
    fm, body = parse_frontmatter(r.stdout)
    assert fm["node_id"] == child_id
    assert fm["status"] == "rejected"
    assert fm["prior_attempts"] == 1
    assert "Prior reviewer feedback" in body
    assert "add returns 0" in body

    # ---- Scenario 6: solver fixes, reviewer commits and approves ----
    write(target / "calc.py", "def add(a, b):\n    return a + b\n")
    run(workspace, "done", child_id, check=True)

    # Reviewer commits with Goalie-Id trailer
    sha = git_commit(target, f"fix: implement add\n\nGoalie-Id: {child_id}", ["calc.py"])

    r = run(workspace, "approve", child_id, check=True)
    assert "done" in r.stdout
    assert "WARNING" not in r.stdout

    log = git_log(target)
    assert f"Goalie-Id: {child_id}" in log

    child_goal = _find_node_dir(workspace, child_id) / "goal.md"
    fm_text = child_goal.read_text().split("---")[1]
    fm = yaml.safe_load(fm_text)
    assert fm.get("verified_sha") == sha


def test_no_work_exit_code(workspace: Path):
    run(workspace, "init", "trivial", "--control-plane", "--target", "target", check=True)
    r = run(workspace, "next", "--role", "reviewer")
    assert r.returncode == 42
    assert "No tasks for role 'reviewer'" in r.stdout


def test_unknown_role(workspace: Path):
    run(workspace, "init", "trivial", "--control-plane", "--target", "target", check=True)
    r = run(workspace, "next", "--role", "ghost")
    assert r.returncode == 43
    assert "unknown role" in r.stderr.lower() or "unknown role" in r.stdout.lower()


def test_tree_shows_unique_short_ids(workspace: Path):
    """goalie tree short IDs must all be distinct."""
    run(workspace, "init", "root goal", "--control-plane", "--target", "target", check=True)
    r = run(workspace, "next", "--role", "planner", check=True)
    fm, _ = parse_frontmatter(r.stdout)
    root_id = fm["node_id"]

    target = workspace / "target"
    write(target / f"goalie_verify_{root_id}.md", "all children done")
    run(target, "split", root_id, "Child A", "Child B", "Child C", check=True)

    r = run(workspace, "tree", check=True)
    short_ids = re.findall(r"`([a-z0-9]+)`", r.stdout)
    assert len(short_ids) == len(set(short_ids)), f"duplicate short IDs in tree: {short_ids}"


def test_rollup_lifecycle(workspace: Path):
    """Full lifecycle: split → plan+solve all children → parent rolls up automatically."""
    target = workspace / "target"
    run(workspace, "init", "Build two functions",
        "--control-plane", "--target", "target", check=True)

    r = run(workspace, "next", "--role", "planner", check=True)
    fm, _ = parse_frontmatter(r.stdout)
    root_id = fm["node_id"]

    write(target / f"goalie_verify_{root_id}.md", "module has add and sub")
    run(target, "split", root_id, "Implement add", "Implement sub", check=True)

    # Plan first child
    r = run(workspace, "next", "--role", "planner", check=True)
    fm, _ = parse_frontmatter(r.stdout)
    child1_id = fm["node_id"]
    write(target / f"goalie_task_{child1_id}.md", "implement add(a,b)")
    write(target / f"goalie_verify_{child1_id}.md", "add(1,2)==3")
    run(target, "plan", child1_id, check=True)

    # Plan second child
    r = run(workspace, "next", "--role", "planner", check=True)
    fm, _ = parse_frontmatter(r.stdout)
    child2_id = fm["node_id"]
    write(target / f"goalie_task_{child2_id}.md", "implement sub(a,b)")
    write(target / f"goalie_verify_{child2_id}.md", "sub(3,1)==2")
    run(target, "plan", child2_id, check=True)

    # Solve + approve child1 (no commit — clean tree, no files changed)
    run(workspace, "done", child1_id, check=True)
    r = run(workspace, "approve", child1_id, check=True)
    assert "done" in r.stdout
    assert "Rolled up" not in r.stdout  # child2 still pending

    # Solve + approve child2 → rollup fires
    run(workspace, "done", child2_id, check=True)
    r = run(workspace, "approve", child2_id, check=True)
    assert "done" in r.stdout
    assert "Rolled up" in r.stdout
    assert "needs_review" in r.stdout

    # Root is now needs_review — reviewer approves it
    r = run(workspace, "next", "--role", "reviewer", check=True)
    fm, _ = parse_frontmatter(r.stdout)
    assert fm["node_id"] == root_id
    assert fm["status"] == "needs_review"

    r = run(workspace, "approve", root_id, check=True)
    assert "done" in r.stdout

    r = run(workspace, "tree", check=True)
    assert "[done]" in r.stdout


def test_done_errors_on_parent_with_children(workspace: Path):
    """goalie done errors if node has children (rollup is automatic)."""
    run(workspace, "init", "root", "--control-plane", "--target", "target", check=True)
    r = run(workspace, "next", "--role", "planner", check=True)
    fm, _ = parse_frontmatter(r.stdout)
    root_id = fm["node_id"]

    target = workspace / "target"
    write(target / f"goalie_verify_{root_id}.md", "children done")
    run(target, "split", root_id, "Child A", check=True)

    r = run(workspace, "done", root_id)
    assert r.returncode == 43
    assert "has children" in r.stderr or "has children" in r.stdout


def test_split_requires_verify_md(workspace: Path):
    """goalie split errors if verify.md not yet written on the node."""
    run(workspace, "init", "root", "--control-plane", "--target", "target", check=True)
    r = run(workspace, "next", "--role", "planner", check=True)
    fm, _ = parse_frontmatter(r.stdout)
    root_id = fm["node_id"]

    r = run(workspace, "split", root_id, "Child A")
    assert r.returncode == 43
    assert "verify.md" in r.stderr


def test_parent_rejection_routing(workspace: Path):
    """Rejected parent with children routes to planner, not solver.
    Planner output includes Existing decomposition section."""
    target = workspace / "target"
    run(workspace, "init", "multi-child goal",
        "--control-plane", "--target", "target", check=True)

    r = run(workspace, "next", "--role", "planner", check=True)
    fm, _ = parse_frontmatter(r.stdout)
    root_id = fm["node_id"]

    write(target / f"goalie_verify_{root_id}.md", "both children done")
    run(target, "split", root_id, "Child A", check=True)

    # Plan and complete the child
    r = run(workspace, "next", "--role", "planner", check=True)
    fm, _ = parse_frontmatter(r.stdout)
    child_id = fm["node_id"]
    write(target / f"goalie_task_{child_id}.md", "do child A")
    write(target / f"goalie_verify_{child_id}.md", "child A criteria")
    run(target, "plan", child_id, check=True)
    run(workspace, "done", child_id, check=True)
    run(workspace, "approve", child_id, check=True)
    # root rolled up → reviewer picks up root

    # Reviewer rejects root
    run(workspace, "reject", root_id, "missing child B", check=True)

    # Solver should NOT see the rejected root (it has children)
    r = run(workspace, "next", "--role", "solver")
    assert r.returncode == 42

    # Planner SHOULD see the rejected root
    r = run(workspace, "next", "--role", "planner", check=True)
    fm, body = parse_frontmatter(r.stdout)
    assert fm["node_id"] == root_id
    assert fm["status"] == "rejected"
    assert "Existing decomposition" in body
    assert "Child A" in body


def test_gitignore_updated_on_init(workspace: Path):
    run(workspace, "init", "A goal",
        "--control-plane", "--target", "target", check=True)
    gi = (workspace / "target" / ".gitignore").read_text()
    assert ".goalie/" in gi
    assert "goalie_task_*.md" in gi
    assert "goalie_verify_*.md" in gi


def test_gitignore_idempotent(workspace: Path):
    run(workspace, "init", "A goal",
        "--control-plane", "--target", "target", check=True)
    before = (workspace / "target" / ".gitignore").read_text()
    from goalie.verbs.init import _update_gitignore
    _update_gitignore(workspace / "target")
    after = (workspace / "target" / ".gitignore").read_text()
    assert before == after
