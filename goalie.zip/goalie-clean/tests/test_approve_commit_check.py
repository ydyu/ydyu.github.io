"""Tests for approve integrity checks: dirty tree, HEAD trailer."""
from __future__ import annotations

import subprocess
from pathlib import Path

import pytest

from tests.conftest import _find_node_dir, git_commit, git_log, parse_frontmatter, run, write


def _setup_needs_review(workspace: Path) -> tuple[str, Path]:
    """Init, plan a leaf, submit it. Returns (node_id, target_path)."""
    target = workspace / "target"
    run(workspace, "init", "test goal", "--control-plane", "--target", "target", check=True)

    r = run(workspace, "next", "--role", "planner", check=True)
    fm, _ = parse_frontmatter(r.stdout)
    root_id = fm["node_id"]

    write(target / f"goalie_verify_{root_id}.md", "child done")
    run(target, "split", root_id, "leaf task", check=True)

    r = run(workspace, "next", "--role", "planner", check=True)
    fm, _ = parse_frontmatter(r.stdout)
    child_id = fm["node_id"]

    write(target / f"goalie_task_{child_id}.md", "do the thing")
    write(target / f"goalie_verify_{child_id}.md", "thing is done")
    run(target, "plan", child_id, check=True)

    write(target / "work.txt", "done")
    run(workspace, "done", child_id, check=True)
    return child_id, target


def test_approve_trailer_present_silent(workspace: Path):
    """Commit with Goalie-Id trailer → approve silently (no WARNING)."""
    child_id, target = _setup_needs_review(workspace)

    sha = git_commit(
        target,
        f"feat: do the thing\n\nGoalie-Id: {child_id}",
        ["work.txt"],
    )

    r = run(workspace, "approve", child_id, check=True)
    assert "done" in r.stdout
    assert "WARNING" not in r.stdout

    log = git_log(target)
    assert f"Goalie-Id: {child_id}" in log

    node_dir = _find_node_dir(workspace, child_id)
    import yaml
    fm = yaml.safe_load(node_dir.joinpath("goal.md").read_text().split("---")[1])
    assert fm.get("verified_sha") == sha


def test_approve_trailer_missing_warns(workspace: Path):
    """Commit without Goalie-Id trailer → approve with WARNING."""
    child_id, target = _setup_needs_review(workspace)

    git_commit(target, "feat: do the thing", ["work.txt"])

    r = run(workspace, "approve", child_id, check=True)
    assert "done" in r.stdout
    assert "WARNING" in r.stdout
    assert "Goalie-Id" in r.stdout


def test_approve_dirty_tree_refused(workspace: Path):
    """Staged-but-uncommitted files → approve refuses with file list."""
    child_id, target = _setup_needs_review(workspace)

    # Stage work.txt but don't commit
    subprocess.check_call(["git", "add", "work.txt"], cwd=str(target))

    r = run(workspace, "approve", child_id)
    assert r.returncode == 43
    assert "uncommitted" in r.stderr or "dirty" in r.stderr or "uncommitted" in r.stdout
    assert "work.txt" in r.stderr or "work.txt" in r.stdout


def test_approve_cleans_up_commit_file(workspace: Path):
    """goalie_commit_<id>.md in target is deleted after approve."""
    child_id, target = _setup_needs_review(workspace)

    git_commit(target, f"feat: do it\n\nGoalie-Id: {child_id}", ["work.txt"])

    commit_file = target / f"goalie_commit_{child_id}.md"
    commit_file.write_text("reviewer commit message")

    r = run(workspace, "approve", child_id, check=True)
    assert "done" in r.stdout
    assert not commit_file.exists()


def test_reject_requires_reason(workspace: Path):
    """reject with empty reason errors."""
    child_id, target = _setup_needs_review(workspace)
    r = run(workspace, "reject", child_id, "   ")
    assert r.returncode == 43
    assert "reason" in r.stderr


def test_reject_records_critique(workspace: Path):
    """reject appends critique and increments prior_attempts."""
    child_id, target = _setup_needs_review(workspace)
    r = run(workspace, "reject", child_id, "insufficient test coverage", check=True)
    assert "rejected" in r.stdout

    node_dir = _find_node_dir(workspace, child_id)
    attempts_text = (node_dir / "attempts.md").read_text()
    assert "insufficient test coverage" in attempts_text

    r = run(workspace, "next", child_id[-8:].lower(), "--role", "solver", check=True)
    fm, body = parse_frontmatter(r.stdout)
    assert fm["prior_attempts"] == 1
    assert "insufficient test coverage" in body
