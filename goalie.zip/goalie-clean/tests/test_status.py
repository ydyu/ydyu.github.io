"""Tests for `goalie status` verb (finding N8)."""
from __future__ import annotations

import re
from pathlib import Path

from tests.conftest import parse_frontmatter, run, write


def _parse_status_table(output: str) -> dict[str, int]:
    """Parse the markdown table from `goalie status` output into a dict."""
    counts: dict[str, int] = {}
    for line in output.splitlines():
        m = re.match(r"\|\s*(\w+)\s*\|\s*(\d+)\s*\|", line)
        if m and m.group(1) != "status":  # skip header row
            counts[m.group(1)] = int(m.group(2))
    return counts


def test_status_fresh_workspace(workspace: Path) -> None:
    """On a fresh workspace the root node is `unplanned`; status reports one unplanned node."""
    run(workspace, "init", "test goal", "--control-plane", "--target", "target", check=True)

    r = run(workspace, "status", check=True)
    assert r.returncode == 0
    assert "| status | count |" in r.stdout
    assert "test goal" in r.stdout

    counts = _parse_status_table(r.stdout)
    assert counts.get("unplanned", 0) == 1


def test_status_counts_pending_nodes(workspace: Path) -> None:
    """After planning two children the status table shows the correct pending count."""
    target = workspace / "target"
    run(workspace, "init", "parent goal", "--control-plane", "--target", "target", check=True)

    # Get root and split into two children
    r = run(workspace, "next", "--role", "planner", check=True)
    fm, _ = parse_frontmatter(r.stdout)
    root_id = fm["node_id"]

    write(target / f"goalie_verify_{root_id}.md", "all children done")
    run(target, "split", root_id, "Child A", "Child B", check=True)

    # Plan both children so they move to pending
    r = run(workspace, "next", "--role", "planner", check=True)
    fm, _ = parse_frontmatter(r.stdout)
    child1_id = fm["node_id"]
    write(target / f"goalie_task_{child1_id}.md", "do child A")
    write(target / f"goalie_verify_{child1_id}.md", "child A done")
    run(target, "plan", child1_id, check=True)

    r = run(workspace, "next", "--role", "planner", check=True)
    fm, _ = parse_frontmatter(r.stdout)
    child2_id = fm["node_id"]
    write(target / f"goalie_task_{child2_id}.md", "do child B")
    write(target / f"goalie_verify_{child2_id}.md", "child B done")
    run(target, "plan", child2_id, check=True)

    r = run(workspace, "status", check=True)
    assert r.returncode == 0
    assert "| status | count |" in r.stdout

    counts = _parse_status_table(r.stdout)
    # Root has verify.md so it is pending; both children are also pending → 3 total
    assert counts.get("pending", 0) == 3


def test_status_mixed_statuses(workspace: Path) -> None:
    """Status table accurately reflects a mix of pending and needs_review nodes."""
    target = workspace / "target"
    run(workspace, "init", "mixed goal", "--control-plane", "--target", "target", check=True)

    r = run(workspace, "next", "--role", "planner", check=True)
    fm, _ = parse_frontmatter(r.stdout)
    root_id = fm["node_id"]

    write(target / f"goalie_verify_{root_id}.md", "both children done")
    run(target, "split", root_id, "Child A", "Child B", check=True)

    # Plan and solve child1 → moves to needs_review
    r = run(workspace, "next", "--role", "planner", check=True)
    fm, _ = parse_frontmatter(r.stdout)
    child1_id = fm["node_id"]
    write(target / f"goalie_task_{child1_id}.md", "task A")
    write(target / f"goalie_verify_{child1_id}.md", "verify A")
    run(target, "plan", child1_id, check=True)
    run(workspace, "done", child1_id, check=True)

    # Plan child2 but leave it pending
    r = run(workspace, "next", "--role", "planner", check=True)
    fm, _ = parse_frontmatter(r.stdout)
    child2_id = fm["node_id"]
    write(target / f"goalie_task_{child2_id}.md", "task B")
    write(target / f"goalie_verify_{child2_id}.md", "verify B")
    run(target, "plan", child2_id, check=True)

    r = run(workspace, "status", check=True)
    assert r.returncode == 0

    counts = _parse_status_table(r.stdout)
    # Root (pending) + child2 (pending) = 2 pending; child1 = 1 needs_review
    assert counts.get("needs_review", 0) == 1
    assert counts.get("pending", 0) == 2


def test_status_table_format(workspace: Path) -> None:
    """Status output includes the header, separator, and root title lines."""
    run(workspace, "init", "my project", "--control-plane", "--target", "target", check=True)

    r = run(workspace, "status", check=True)
    lines = r.stdout.splitlines()

    # First line should be "Root: <title> (`<short_id>`)"
    assert lines[0].startswith("Root:")
    assert "my project" in lines[0]

    # Table header and separator are present
    assert any("| status | count |" in l for l in lines)
    assert any("|---|---|" in l for l in lines)
