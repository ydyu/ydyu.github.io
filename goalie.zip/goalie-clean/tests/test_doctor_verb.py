"""Tests for `goalie doctor` verb."""
from __future__ import annotations

from pathlib import Path

import pytest

from tests.conftest import _find_node_dir, parse_frontmatter, run, write


@pytest.fixture
def clean_workspace(workspace: Path) -> Path:
    """workspace with a valid initialized control plane."""
    run(workspace, "init", "Root goal",
        "--control-plane", "--target", "target", check=True)
    return workspace


def _nodes_root(workspace: Path) -> Path:
    return workspace / ".goalie" / "nodes"


def test_doctor_no_orphans(clean_workspace: Path):
    r = run(clean_workspace, "doctor", check=True)
    assert "No orphan" in r.stdout


def test_doctor_detects_raw_ulid_dir(clean_workspace: Path):
    fake = _nodes_root(clean_workspace) / "01KQZZZZZZZZZZZZZZZZZZZZZZ"
    fake.mkdir()
    (fake / "task.md").write_text("some task")

    r = run(clean_workspace, "doctor")
    assert r.returncode != 0
    assert "01KQZZZZZZZZZZZZZZZZZZZZZZ" in r.stdout
    assert "task.md" in r.stdout


def test_doctor_detects_truncated_slug_dir(clean_workspace: Path):
    fake = _nodes_root(clean_workspace) / "create-goalie-notes-md-at-repository-root-and-pl"
    fake.mkdir()
    (fake / "task.md").write_text("orphan")
    (fake / "verify.md").write_text("orphan")

    r = run(clean_workspace, "doctor")
    assert r.returncode != 0
    assert "create-goalie-notes-md-at-repository-root-and-pl" in r.stdout


def test_doctor_prune_removes_orphans(clean_workspace: Path):
    nr = _nodes_root(clean_workspace)
    orphan1 = nr / "01KQAAAAAAAAAAAAAAAAAAAAAAA"
    orphan2 = nr / "bad-slug-guess"
    orphan1.mkdir()
    orphan2.mkdir()
    (orphan1 / "task.md").write_text("x")

    r = run(clean_workspace, "doctor", "--prune", check=True)
    assert "Pruned 2" in r.stdout
    assert not orphan1.exists()
    assert not orphan2.exists()


def test_doctor_prune_leaves_real_nodes(clean_workspace: Path):
    # create a real node via split so we have a tracked slug dir
    r = run(clean_workspace, "next", "--role", "planner", check=True)
    fm, _ = parse_frontmatter(r.stdout)
    node_id = fm["node_id"]
    # write verify.md (required before split)
    node_dir = _find_node_dir(clean_workspace, node_id)
    write(node_dir / "verify.md", "child done")
    run(clean_workspace, "split", node_id, "Child A", check=True)

    # plant an orphan alongside it
    (_nodes_root(clean_workspace) / "orphan-xyz").mkdir()

    r = run(clean_workspace, "doctor", "--prune", check=True)
    assert "Pruned 1" in r.stdout
    # real node dirs untouched
    tracked = [d for d in _nodes_root(clean_workspace).iterdir()
               if d.is_dir() and (d / "goal.md").exists()]
    assert len(tracked) >= 2  # root + child-a
