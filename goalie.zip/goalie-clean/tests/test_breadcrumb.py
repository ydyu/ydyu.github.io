"""Tests for ancestor breadcrumb in `goalie next` Context section."""
from __future__ import annotations

from pathlib import Path

import pytest

from tests.conftest import _find_node_dir, parse_frontmatter, run, write


@pytest.fixture
def three_level_tree_with_bodies(workspace: Path):
    """3-level tree with real goal bodies at root and mid."""
    run(workspace, "init", "Root goal",
        "--control-plane", "--target", "target", check=True)

    target = workspace / "target"

    # Root: stage goal+verify then split (split installs staging files)
    r = run(workspace, "next", "--role", "planner", check=True)
    fm, _ = parse_frontmatter(r.stdout)
    root_id = fm["node_id"]

    write(target / f"goalie_goal_{root_id}.md", "Root intent: the whole enchilada.")
    write(target / f"goalie_verify_{root_id}.md", "root verify")
    run(target, "split", root_id, "Mid goal", check=True)

    # Mid: stage goal+verify then split
    r = run(workspace, "next", "--role", "planner", check=True)
    fm, _ = parse_frontmatter(r.stdout)
    mid_id = fm["node_id"]

    write(target / f"goalie_goal_{mid_id}.md", "Mid intent: the middle layer.")
    write(target / f"goalie_verify_{mid_id}.md", "mid verify")
    run(target, "split", mid_id, "Leaf goal", check=True)

    # Leaf (unplanned)
    r = run(workspace, "next", "--role", "planner", check=True)
    fm, _ = parse_frontmatter(r.stdout)
    leaf_id = fm["node_id"]

    return workspace, root_id, mid_id, leaf_id


def test_context_includes_root_ancestor(three_level_tree_with_bodies):
    workspace, root_id, mid_id, leaf_id = three_level_tree_with_bodies

    r = run(workspace, "next", leaf_id[-8:].lower(), "--role", "planner", check=True)
    assert "Root goal" in r.stdout
    assert "Root intent: the whole enchilada." in r.stdout


def test_context_ancestors_in_order(three_level_tree_with_bodies):
    workspace, root_id, mid_id, leaf_id = three_level_tree_with_bodies

    r = run(workspace, "next", leaf_id[-8:].lower(), "--role", "planner", check=True)
    ctx_start = r.stdout.find("## Context")
    assert ctx_start >= 0, "## Context section not found"
    ancestors_pos = r.stdout.find("Ancestors:", ctx_start)
    root_pos = r.stdout.find("Root goal", ancestors_pos)
    mid_pos = r.stdout.find("Mid goal", root_pos)
    assert ancestors_pos < root_pos < mid_pos, (
        "Root must appear before Mid inside the Ancestors block"
    )


def test_context_mid_body_shown(three_level_tree_with_bodies):
    """Immediate parent's body appears in the Ancestors block."""
    workspace, root_id, mid_id, leaf_id = three_level_tree_with_bodies

    r = run(workspace, "next", leaf_id[-8:].lower(), "--role", "planner", check=True)
    assert "Mid intent: the middle layer." in r.stdout


def test_context_title_repeat_ancestor_has_no_body_block(three_level_tree_with_bodies):
    """Leaf has no real body — show renders it as _not written_."""
    workspace, root_id, mid_id, leaf_id = three_level_tree_with_bodies

    r = run(workspace, "show", leaf_id[-8:].lower(), check=True)
    assert "_not written_" in r.stdout


def test_parent_body_shown_at_depth_one(workspace: Path):
    """Direct child of root: root body appears in the Ancestors block."""
    run(workspace, "init", "Root goal",
        "--control-plane", "--target", "target", check=True)

    target = workspace / "target"
    r = run(workspace, "next", "--role", "planner", check=True)
    fm, _ = parse_frontmatter(r.stdout)
    root_id = fm["node_id"]

    write(target / f"goalie_goal_{root_id}.md", "Root intent: the whole enchilada.")
    write(target / f"goalie_verify_{root_id}.md", "root verify")
    run(target, "split", root_id, "Child goal", check=True)

    r = run(workspace, "next", "--role", "planner", check=True)
    ctx_start = r.stdout.find("## Context")
    assert ctx_start >= 0
    assert "Ancestors:" in r.stdout[ctx_start:]
    assert "Root goal" in r.stdout[ctx_start:]
    assert "Root intent: the whole enchilada." in r.stdout[ctx_start:]


def test_context_title_only_ancestor_no_body_lines(workspace: Path):
    """Direct child of root with no root body: Ancestors block shows title but no body lines."""
    run(workspace, "init", "Root goal",
        "--control-plane", "--target", "target", check=True)

    target = workspace / "target"
    r = run(workspace, "next", "--role", "planner", check=True)
    fm, _ = parse_frontmatter(r.stdout)
    root_id = fm["node_id"]

    write(target / f"goalie_verify_{root_id}.md", "root verify")
    run(target, "split", root_id, "Child goal", check=True)

    r = run(workspace, "next", "--role", "planner", check=True)
    ctx_start = r.stdout.find("## Context")
    assert ctx_start >= 0
    ctx = r.stdout[ctx_start:]
    assert "Ancestors:" in ctx
    assert "Root goal" in ctx
    assert "  > " not in ctx


def test_goal_section_shown_when_body_present(three_level_tree_with_bodies):
    workspace, root_id, mid_id, leaf_id = three_level_tree_with_bodies
    target = workspace / "target"

    write(target / f"goalie_goal_{leaf_id}.md", "Leaf purpose: handles the final concern.")
    write(target / f"goalie_task_{leaf_id}.md", "Do the leaf thing.")
    write(target / f"goalie_verify_{leaf_id}.md", "- leaf done")
    run(target, "plan", leaf_id, check=True)

    # Node is pending after plan — solver picks it up
    r = run(workspace, "next", leaf_id[-8:].lower(), "--role", "solver", check=True)
    assert "## Goal" in r.stdout
    assert "Leaf purpose: handles the final concern." in r.stdout


def test_goal_section_absent_when_no_body(three_level_tree_with_bodies):
    workspace, root_id, mid_id, leaf_id = three_level_tree_with_bodies

    r = run(workspace, "next", leaf_id[-8:].lower(), "--role", "planner", check=True)
    assert "## Goal" not in r.stdout
