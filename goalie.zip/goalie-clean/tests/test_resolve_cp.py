"""Unit tests for the 4-step control-plane resolution precedence."""
from __future__ import annotations

import os
from pathlib import Path

import pytest

from goalie.config import CONFIG_FILENAME, resolve_control_plane


def _make_cp(path: Path) -> Path:
    """Create a minimal valid control plane at `path`."""
    path.mkdir(parents=True, exist_ok=True)
    (path / CONFIG_FILENAME).write_text("target_repo: .\nroles: {}\n")
    return path


# ---------------------------------------------------------------------------
# Step 1: override flag wins
# ---------------------------------------------------------------------------

def test_override_wins_over_env_and_walkup(tmp_path, monkeypatch):
    cp_override = _make_cp(tmp_path / "explicit_cp")
    cp_env = _make_cp(tmp_path / "env_cp")
    cp_walkup = _make_cp(tmp_path / "project" / ".goalie")
    monkeypatch.setenv("GOALIE_CP", str(cp_env))
    result = resolve_control_plane(cp_walkup.parent, override=str(cp_override))
    assert result == cp_override


def test_override_missing_config_raises(tmp_path):
    bad = tmp_path / "no_such"
    bad.mkdir()
    with pytest.raises(FileNotFoundError, match="--cp"):
        resolve_control_plane(tmp_path, override=str(bad))


def test_override_nonexistent_raises(tmp_path):
    with pytest.raises(FileNotFoundError, match="--cp"):
        resolve_control_plane(tmp_path, override=str(tmp_path / "ghost"))


# ---------------------------------------------------------------------------
# Step 2: GOALIE_CP env var beats walk-up
# ---------------------------------------------------------------------------

def test_env_var_beats_walkup(tmp_path, monkeypatch):
    cp_env = _make_cp(tmp_path / "env_cp")
    cwd = tmp_path / "project"
    _make_cp(cwd / ".goalie")
    monkeypatch.setenv("GOALIE_CP", str(cp_env))
    result = resolve_control_plane(cwd)
    assert result == cp_env


def test_env_var_missing_config_raises(tmp_path, monkeypatch):
    bad = tmp_path / "no_config"
    bad.mkdir()
    monkeypatch.setenv("GOALIE_CP", str(bad))
    with pytest.raises(FileNotFoundError, match="GOALIE_CP"):
        resolve_control_plane(tmp_path)


# ---------------------------------------------------------------------------
# Step 3: walk-up still works for in-repo mode
# ---------------------------------------------------------------------------

def test_walkup_finds_goalie_dir(tmp_path, monkeypatch):
    monkeypatch.delenv("GOALIE_CP", raising=False)
    cp = _make_cp(tmp_path / ".goalie")
    cwd = tmp_path / "sub" / "dir"
    cwd.mkdir(parents=True)
    result = resolve_control_plane(cwd)
    assert result == cp


def test_walkup_from_cp_itself(tmp_path, monkeypatch):
    monkeypatch.delenv("GOALIE_CP", raising=False)
    cp = _make_cp(tmp_path / ".goalie")
    result = resolve_control_plane(tmp_path)
    assert result == cp


# ---------------------------------------------------------------------------
# Step 4: loud error with both remediation paths
# ---------------------------------------------------------------------------

def test_no_cp_loud_error(tmp_path, monkeypatch):
    monkeypatch.delenv("GOALIE_CP", raising=False)
    isolated = tmp_path / "nowhere"
    isolated.mkdir()
    with pytest.raises(FileNotFoundError) as exc_info:
        resolve_control_plane(isolated)
    msg = str(exc_info.value)
    assert "GOALIE_CP" in msg
    assert ".goalie/" in msg
