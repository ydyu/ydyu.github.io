"""Tests for `goalie plan` goal body absorption."""
from __future__ import annotations

from pathlib import Path

import pytest

from tests.conftest import _find_node_dir, parse_frontmatter, run, write


@pytest.fixture
def leaf_workspace(workspace: Path):
    """workspace with one unplanned leaf ready to plan."""
    run(workspace, "init", "Root goal",
        "--control-plane", "--target", "target", check=True)
    r = run(workspace, "next", "--role", "planner", check=True)
    fm, _ = parse_frontmatter(r.stdout)
    root_id = fm["node_id"]

    target = workspace / "target"
    # Stage verify for root, then split (split installs the staging file)
    write(target / f"goalie_verify_{root_id}.md", "root verify")
    run(target, "split", root_id, "Leaf goal", check=True)

    r = run(workspace, "next", "--role", "planner", check=True)
    fm, _ = parse_frontmatter(r.stdout)
    leaf_id = fm["node_id"]
    return workspace, leaf_id


def test_goal_body_written(leaf_workspace):
    workspace, leaf_id = leaf_workspace
    target = workspace / "target"

    write(target / f"goalie_goal_{leaf_id}.md", "This subtree handles X so that Y is achieved.")
    write(target / f"goalie_task_{leaf_id}.md", "Do the thing.")
    write(target / f"goalie_verify_{leaf_id}.md", "- thing done")
    r = run(target, "plan", leaf_id, check=True)

    assert "goal" in r.stdout
    assert not (target / f"goalie_goal_{leaf_id}.md").exists()

    node_dir = _find_node_dir(workspace, leaf_id)
    goal_md = (node_dir / "goal.md").read_text()
    assert "This subtree handles X so that Y is achieved." in goal_md


def test_goal_body_overwrite_on_second_plan(leaf_workspace):
    """Goal body can be updated by re-running plan after initial leaf plan."""
    workspace, leaf_id = leaf_workspace
    target = workspace / "target"

    write(target / f"goalie_goal_{leaf_id}.md", "v1 intent")
    write(target / f"goalie_task_{leaf_id}.md", "do the thing")
    write(target / f"goalie_verify_{leaf_id}.md", "- thing done")
    run(target, "plan", leaf_id, check=True)

    # Node is now pending; update goal body alone (task+verify already on node)
    write(target / f"goalie_goal_{leaf_id}.md", "v2 refined intent")
    r = run(target, "plan", leaf_id, check=True)
    assert r.returncode == 0

    node_dir = _find_node_dir(workspace, leaf_id)
    assert "v2 refined intent" in (node_dir / "goal.md").read_text()


def test_goal_staging_file_deleted_on_success(leaf_workspace):
    workspace, leaf_id = leaf_workspace
    target = workspace / "target"

    write(target / f"goalie_goal_{leaf_id}.md", "Some intent.")
    write(target / f"goalie_task_{leaf_id}.md", "Do the thing.")
    write(target / f"goalie_verify_{leaf_id}.md", "- thing done")
    run(target, "plan", leaf_id, check=True)

    assert not (target / f"goalie_goal_{leaf_id}.md").exists()


def test_goal_with_task_and_verify(leaf_workspace):
    workspace, leaf_id = leaf_workspace
    target = workspace / "target"

    write(target / f"goalie_goal_{leaf_id}.md", "Full intent.")
    write(target / f"goalie_task_{leaf_id}.md", "Do the thing.")
    write(target / f"goalie_verify_{leaf_id}.md", "- thing done")

    r = run(target, "plan", leaf_id, check=True)
    assert "goal" in r.stdout
    assert "task + verify" in r.stdout

    node_dir = _find_node_dir(workspace, leaf_id)
    assert "Full intent." in (node_dir / "goal.md").read_text()
    assert "Do the thing." in (node_dir / "task.md").read_text()


def test_empty_goal_file_errors(leaf_workspace):
    workspace, leaf_id = leaf_workspace
    target = workspace / "target"

    write(target / f"goalie_goal_{leaf_id}.md", "   ")
    write(target / f"goalie_task_{leaf_id}.md", "Do the thing.")
    write(target / f"goalie_verify_{leaf_id}.md", "- thing done")
    r = run(target, "plan", leaf_id)
    assert r.returncode != 0
    assert "empty" in r.stderr


def test_goal_in_gitignore(workspace: Path):
    run(workspace, "init", "A goal",
        "--control-plane", "--target", "target", check=True)
    gi = (workspace / "target" / ".gitignore").read_text()
    assert "goalie_goal_*.md" in gi
