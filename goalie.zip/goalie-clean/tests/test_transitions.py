"""Matrix test: every (verb, status) combination + REQUIRED_FILES + plan staging cases."""
from __future__ import annotations

import pytest
from pathlib import Path

from tests.conftest import _find_node_dir, parse_frontmatter, run, write
from goalie.transitions import LEGAL_TRANSITIONS, REQUIRED_FILES
from goalie.store import Status


# ── helpers ──────────────────────────────────────────────────────────────────

def _init_leaf(workspace: Path) -> tuple[str, Path]:
    """Init workspace, split root into one leaf, return (leaf_id, target)."""
    target = workspace / "target"
    run(workspace, "init", "root", "--control-plane", "--target", "target", check=True)

    r = run(workspace, "next", "--role", "planner", check=True)
    from tests.conftest import parse_frontmatter
    fm, _ = parse_frontmatter(r.stdout)
    root_id = fm["node_id"]

    write(target / f"goalie_verify_{root_id}.md", "leaf done")
    run(target, "split", root_id, "leaf task", check=True)

    r = run(workspace, "next", "--role", "planner", check=True)
    fm, _ = parse_frontmatter(r.stdout)
    return fm["node_id"], target


def _plan_leaf(workspace: Path, leaf_id: str, target: Path) -> None:
    write(target / f"goalie_task_{leaf_id}.md", "do the task")
    write(target / f"goalie_verify_{leaf_id}.md", "task is done")
    run(target, "plan", leaf_id, check=True)


# ── LEGAL_TRANSITIONS sanity ─────────────────────────────────────────────────

def test_all_verbs_have_required_files_entry():
    verbs = {v for (v, _) in LEGAL_TRANSITIONS}
    for verb in verbs:
        assert verb in REQUIRED_FILES, f"REQUIRED_FILES missing entry for verb '{verb}'"


# ── plan verb ────────────────────────────────────────────────────────────────

def test_plan_happy_path(workspace: Path):
    leaf_id, target = _init_leaf(workspace)
    write(target / f"goalie_task_{leaf_id}.md", "Implement the module.")
    write(target / f"goalie_verify_{leaf_id}.md", "- module.py exists")
    r = run(target, "plan", leaf_id, check=True)
    assert "pending" in r.stdout
    assert not (target / f"goalie_task_{leaf_id}.md").exists()
    assert not (target / f"goalie_verify_{leaf_id}.md").exists()


def test_plan_auto_detect(workspace: Path):
    leaf_id, target = _init_leaf(workspace)
    write(target / f"goalie_task_{leaf_id}.md", "Do the thing.")
    write(target / f"goalie_verify_{leaf_id}.md", "- thing done")
    r = run(target, "plan", check=True)
    assert "pending" in r.stdout


def test_plan_no_staging_files_and_node_missing_files(workspace: Path):
    leaf_id, target = _init_leaf(workspace)
    r = run(target, "plan", leaf_id)
    assert r.returncode != 0
    # With explicit id and no staging files, REQUIRED_FILES check fires
    assert "task.md" in r.stderr or "verify.md" in r.stderr


def test_plan_missing_verify_only_task(workspace: Path):
    """Staging task without verify → REQUIRED_FILES check fails post-install."""
    leaf_id, target = _init_leaf(workspace)
    write(target / f"goalie_task_{leaf_id}.md", "Do the thing.")
    r = run(target, "plan", leaf_id)
    assert r.returncode != 0
    assert "verify.md" in r.stderr


def test_plan_empty_task_file(workspace: Path):
    leaf_id, target = _init_leaf(workspace)
    write(target / f"goalie_task_{leaf_id}.md", "   ")
    write(target / f"goalie_verify_{leaf_id}.md", "- criteria")
    r = run(target, "plan", leaf_id)
    assert r.returncode != 0
    assert "empty" in r.stderr


def test_plan_overwrites_existing_without_force(workspace: Path):
    """plan overwrites by default — no --force needed."""
    leaf_id, target = _init_leaf(workspace)
    write(target / f"goalie_task_{leaf_id}.md", "v1 instructions")
    write(target / f"goalie_verify_{leaf_id}.md", "- criteria")
    run(target, "plan", leaf_id, check=True)

    write(target / f"goalie_task_{leaf_id}.md", "v2 instructions")
    write(target / f"goalie_verify_{leaf_id}.md", "- new criteria")
    r = run(target, "plan", leaf_id, check=True)
    assert "task + verify" in r.stdout
    node_dir = _find_node_dir(workspace, leaf_id)
    assert "v2 instructions" in (node_dir / "task.md").read_text()


def test_plan_stale_warning(workspace: Path):
    leaf_id, target = _init_leaf(workspace)
    write(target / f"goalie_task_{leaf_id}.md", "Do the thing.")
    write(target / f"goalie_verify_{leaf_id}.md", "- thing done")
    write(target / "goalie_task_ZZZZZZZZZZZZZZZZZZZZZZZZZZ.md", "old")
    r = run(target, "plan", leaf_id, check=True)
    assert "WARNING" in r.stdout
    assert "ZZZZZZZZZZZZZZZZZZZZZZZZZZ" in r.stdout


def test_plan_multiple_stageable_ids_no_ident(workspace: Path):
    leaf_id, target = _init_leaf(workspace)
    write(target / f"goalie_task_{leaf_id}.md", "Do the thing.")
    write(target / f"goalie_verify_{leaf_id}.md", "- thing done")
    write(target / "goalie_task_AAAAAAAAAAAAAAAAAAAAAAAAAA.md", "other")
    write(target / "goalie_verify_AAAAAAAAAAAAAAAAAAAAAAAAAA.md", "- other")
    r = run(target, "plan")
    assert r.returncode != 0
    assert "Multiple staging" in r.stderr


def test_plan_wrong_status_does_not_flip(workspace: Path):
    """plan on a pending node installs files but does not attempt a second flip."""
    leaf_id, target = _init_leaf(workspace)
    _plan_leaf(workspace, leaf_id, target)  # now pending

    # Update task+verify on a pending node
    write(target / f"goalie_task_{leaf_id}.md", "updated task")
    write(target / f"goalie_verify_{leaf_id}.md", "- updated")
    r = run(target, "plan", leaf_id, check=True)
    assert "pending" not in r.stdout  # no second flip


# ── done verb ────────────────────────────────────────────────────────────────

def test_done_from_pending(workspace: Path):
    leaf_id, target = _init_leaf(workspace)
    _plan_leaf(workspace, leaf_id, target)
    r = run(workspace, "done", leaf_id, check=True)
    assert "needs_review" in r.stdout


def test_done_from_rejected(workspace: Path):
    leaf_id, target = _init_leaf(workspace)
    _plan_leaf(workspace, leaf_id, target)
    run(workspace, "done", leaf_id, check=True)
    run(workspace, "reject", leaf_id, "bad work", check=True)
    r = run(workspace, "done", leaf_id, check=True)
    assert "needs_review" in r.stdout


def test_done_wrong_status(workspace: Path):
    leaf_id, target = _init_leaf(workspace)
    # unplanned → done should fail
    r = run(workspace, "done", leaf_id)
    assert r.returncode == 43
    assert "unplanned" in r.stderr or "pending" in r.stderr


def test_done_has_no_planned_flag(workspace: Path):
    """--planned flag must not exist on done."""
    r = run(workspace, "done", "--help")
    assert "--planned" not in r.stdout


# ── approve verb ──────────────────────────────────────────────────────────────

def test_approve_wrong_status(workspace: Path):
    leaf_id, target = _init_leaf(workspace)
    r = run(workspace, "approve", leaf_id)
    assert r.returncode == 43
    assert "needs_review" in r.stderr


def test_approve_from_needs_review(workspace: Path):
    leaf_id, target = _init_leaf(workspace)
    _plan_leaf(workspace, leaf_id, target)
    run(workspace, "done", leaf_id, check=True)
    r = run(workspace, "approve", leaf_id, check=True)
    assert "done" in r.stdout


# ── reject verb ──────────────────────────────────────────────────────────────

def test_reject_from_needs_review(workspace: Path):
    leaf_id, target = _init_leaf(workspace)
    _plan_leaf(workspace, leaf_id, target)
    run(workspace, "done", leaf_id, check=True)
    r = run(workspace, "reject", leaf_id, "not good enough", check=True)
    assert "rejected" in r.stdout


def test_reject_empty_reason(workspace: Path):
    leaf_id, target = _init_leaf(workspace)
    _plan_leaf(workspace, leaf_id, target)
    run(workspace, "done", leaf_id, check=True)
    r = run(workspace, "reject", leaf_id, "   ")
    assert r.returncode == 43
    assert "reason" in r.stderr


def test_reject_wrong_status(workspace: Path):
    leaf_id, target = _init_leaf(workspace)
    r = run(workspace, "reject", leaf_id, "some reason")
    assert r.returncode == 43
    assert "needs_review" in r.stderr


# ── split REQUIRED_FILES ─────────────────────────────────────────────────────

def test_split_requires_verify_in_staging_or_node(workspace: Path):
    """split without verify.md in staging or on node → error."""
    run(workspace, "init", "root", "--control-plane", "--target", "target", check=True)
    r = run(workspace, "next", "--role", "planner", check=True)
    fm, _ = parse_frontmatter(r.stdout)
    root_id = fm["node_id"]
    r = run(workspace, "split", root_id, "Child A")
    assert r.returncode == 43
    assert "verify.md" in r.stderr


def test_split_with_verify_in_staging(workspace: Path):
    """split installs verify from staging before creating children."""
    run(workspace, "init", "root", "--control-plane", "--target", "target", check=True)
    r = run(workspace, "next", "--role", "planner", check=True)
    fm, _ = parse_frontmatter(r.stdout)
    root_id = fm["node_id"]
    target = workspace / "target"
    write(target / f"goalie_verify_{root_id}.md", "children done")
    r = run(target, "split", root_id, "Child A", "Child B", check=True)
    assert "pending" in r.stdout
    node_dir = _find_node_dir(workspace, root_id)
    assert (node_dir / "verify.md").exists()


# ── help grouping ─────────────────────────────────────────────────────────────

def test_help_groups_by_role(workspace: Path):
    r = run(workspace, "--help")
    assert "Planner" in r.stdout
    assert "Solver" in r.stdout
    assert "Reviewer" in r.stdout
    assert "approve" in r.stdout
    assert "reject" in r.stdout
    # verify command removed; show description may still say "verify"
    assert "│ verify" not in r.stdout
