"""Tests for parallel support (targeting specific nodes in goalie next)."""
from __future__ import annotations
from pathlib import Path
from tests.conftest import _find_node_dir, parse_frontmatter, run, write

def test_next_with_targeted_id(workspace: Path):
    run(workspace, "init", "Parallel work goal", "--control-plane", "--target", "target", check=True)

    target = workspace / "target"

    # Get root ID and split it (with verify staging)
    r = run(workspace, "next", "--role", "planner", check=True)
    fm, _ = parse_frontmatter(r.stdout)
    root_id = fm["node_id"]

    write(target / f"goalie_verify_{root_id}.md", "all children done")
    run(target, "split", root_id, "Task A", "Task B", check=True)

    # Plan child 1 via staging
    r1 = run(workspace, "next", "--role", "planner", check=True)
    child1_id = parse_frontmatter(r1.stdout)[0]["node_id"]
    write(target / f"goalie_task_{child1_id}.md", "do A")
    write(target / f"goalie_verify_{child1_id}.md", "A done")
    run(target, "plan", child1_id, check=True)

    # Plan child 2 via staging
    r2 = run(workspace, "next", "--role", "planner", check=True)
    child2_id = parse_frontmatter(r2.stdout)[0]["node_id"]
    write(target / f"goalie_task_{child2_id}.md", "do B")
    write(target / f"goalie_verify_{child2_id}.md", "B done")
    run(target, "plan", child2_id, check=True)

    # Verify we can target them specifically for solver
    r_a = run(workspace, "next", child1_id, "--role", "solver", check=True)
    assert parse_frontmatter(r_a.stdout)[0]["node_id"] == child1_id

    r_b = run(workspace, "next", child2_id, "--role", "solver", check=True)
    assert parse_frontmatter(r_b.stdout)[0]["node_id"] == child2_id

    # Root is pending but has children — solver cannot pick it up
    r_fail = run(workspace, "next", root_id, "--role", "solver")
    assert r_fail.returncode == 43
    assert "not actionable" in r_fail.stderr or "not actionable" in r_fail.stdout

def test_next_with_invalid_id(workspace: Path):
    run(workspace, "init", "minimal", "--control-plane", "--target", "target", check=True)
    r = run(workspace, "next", "nonexistent-id", "--role", "solver")
    assert r.returncode == 43
    assert "No node matches" in r.stderr or "No node matches" in r.stdout
