"""Tests for `goalie show` verb."""
from __future__ import annotations

from pathlib import Path

import pytest

from tests.conftest import _find_node_dir, parse_frontmatter, run, write


@pytest.fixture
def three_level_tree(workspace: Path):
    """Control plane with root → mid → leaf (3-level tree)."""
    run(workspace, "init", "Root goal",
        "--control-plane", "--target", "target", check=True)

    target = workspace / "target"

    # Root: stage verify then split (split installs it)
    r = run(workspace, "next", "--role", "planner", check=True)
    fm, _ = parse_frontmatter(r.stdout)
    root_id = fm["node_id"]
    write(target / f"goalie_verify_{root_id}.md", "root done when mid is done")
    run(target, "split", root_id, "Mid goal", check=True)

    # Mid: stage verify then split
    r = run(workspace, "next", "--role", "planner", check=True)
    fm, _ = parse_frontmatter(r.stdout)
    mid_id = fm["node_id"]
    write(target / f"goalie_verify_{mid_id}.md", "mid done when leaf is done")
    run(target, "split", mid_id, "Leaf goal", check=True)

    # Leaf (unplanned)
    r = run(workspace, "next", "--role", "planner", check=True)
    fm, _ = parse_frontmatter(r.stdout)
    leaf_id = fm["node_id"]

    return workspace, root_id, mid_id, leaf_id


def test_show_all_four_sections(three_level_tree):
    workspace, root_id, mid_id, leaf_id = three_level_tree
    short_leaf = leaf_id[-8:].lower()

    r = run(workspace, "show", short_leaf, check=True)
    assert "## Goal" in r.stdout
    assert "## Task" in r.stdout
    assert "## Acceptance" in r.stdout
    # No Q&A section when there are no questions
    assert "## Q&A" not in r.stdout


def test_show_title_repeat_body_is_not_written(three_level_tree):
    workspace, root_id, mid_id, leaf_id = three_level_tree
    short_leaf = leaf_id[-8:].lower()

    r = run(workspace, "show", short_leaf, check=True)
    # Leaf was never given a real body — title-repeat should show as _not written_
    assert "_not written_" in r.stdout


def test_show_real_body_displayed(three_level_tree):
    workspace, root_id, mid_id, leaf_id = three_level_tree
    target = workspace / "target"

    write(target / f"goalie_goal_{leaf_id}.md", "This subtree handles the leaf concern.")
    write(target / f"goalie_task_{leaf_id}.md", "Do the leaf thing.")
    write(target / f"goalie_verify_{leaf_id}.md", "- leaf done")
    run(target, "plan", leaf_id, check=True)

    r = run(workspace, "show", leaf_id[-8:].lower(), check=True)
    assert "This subtree handles the leaf concern." in r.stdout
    assert "_not written_" not in r.stdout


def test_show_task_and_verify_content(three_level_tree):
    workspace, root_id, mid_id, leaf_id = three_level_tree
    target = workspace / "target"

    write(target / f"goalie_task_{leaf_id}.md", "Do the leaf thing.")
    write(target / f"goalie_verify_{leaf_id}.md", "- leaf done")
    run(target, "plan", leaf_id, check=True)

    r = run(workspace, "show", leaf_id[-8:].lower(), check=True)
    assert "Do the leaf thing." in r.stdout
    assert "- leaf done" in r.stdout


def test_show_not_yet_planned_when_absent(three_level_tree):
    workspace, root_id, mid_id, leaf_id = three_level_tree

    r = run(workspace, "show", leaf_id[-8:].lower(), check=True)
    assert "_not yet planned_" in r.stdout


def test_show_includes_node_id_and_status(three_level_tree):
    workspace, root_id, mid_id, leaf_id = three_level_tree
    short_leaf = leaf_id[-8:].lower()

    r = run(workspace, "show", short_leaf, check=True)
    assert short_leaf in r.stdout
    assert "unplanned" in r.stdout


def test_show_unknown_id_errors(three_level_tree):
    workspace, *_ = three_level_tree
    r = run(workspace, "show", "ZZZZZZZZZZZZ")
    assert r.returncode != 0
    assert "ERROR" in r.stderr


def test_show_read_only_no_lock_needed(three_level_tree):
    """show must not require the index lock — run two in parallel (serial here for simplicity)."""
    workspace, root_id, mid_id, leaf_id = three_level_tree
    short_root = root_id[-8:].lower()
    short_leaf = leaf_id[-8:].lower()

    r1 = run(workspace, "show", short_root, check=True)
    r2 = run(workspace, "show", short_leaf, check=True)
    assert "Root goal" in r1.stdout
    assert "Leaf goal" in r2.stdout
