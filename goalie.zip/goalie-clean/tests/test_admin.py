"""Admin verb tests: set-status, rm, rm --recursive, reparent."""
from __future__ import annotations

import yaml
from pathlib import Path

from tests.conftest import _find_node_dir, parse_frontmatter, run, write


def test_admin_set_status(workspace: Path):
    """admin set-status bypasses state machine."""
    run(workspace, "init", "root", "--control-plane", "--target", "target", check=True)
    r = run(workspace, "next", "--role", "planner", check=True)
    fm, _ = parse_frontmatter(r.stdout)
    nid = fm["node_id"]

    r = run(workspace, "admin", "set-status", nid, "done", check=True)
    assert "done" in r.stdout

    r = run(workspace, "tree", check=True)
    assert "[done]" in r.stdout


def test_admin_rm(workspace: Path):
    """admin rm deletes a leaf node."""
    run(workspace, "init", "root", "--control-plane", "--target", "target", check=True)
    r = run(workspace, "next", "--role", "planner", check=True)
    fm, _ = parse_frontmatter(r.stdout)
    root_id = fm["node_id"]

    root_dir = _find_node_dir(workspace, root_id)
    write(root_dir / "verify.md", "child done")
    run(workspace, "split", root_id, "Child A", check=True)

    r = run(workspace, "next", "--role", "planner", check=True)
    fm, _ = parse_frontmatter(r.stdout)
    child_id = fm["node_id"]

    r = run(workspace, "admin", "rm", child_id, check=True)
    assert "Deleted 1" in r.stdout

    r = run(workspace, "tree", check=True)
    assert "Child A" not in r.stdout


def test_admin_rm_recursive(workspace: Path):
    """admin rm --recursive deletes a subtree."""
    run(workspace, "init", "root", "--control-plane", "--target", "target", check=True)
    r = run(workspace, "next", "--role", "planner", check=True)
    fm, _ = parse_frontmatter(r.stdout)
    root_id = fm["node_id"]

    root_dir = _find_node_dir(workspace, root_id)
    write(root_dir / "verify.md", "children done")
    run(workspace, "split", root_id, "Child A", "Child B", check=True)

    # rm root (the actual root) without --recursive should fail
    r = run(workspace, "admin", "rm", root_id)
    assert r.returncode == 43
    assert "recursive" in r.stderr.lower() or "root" in r.stderr.lower()

    # now create a grandchild under Child A so it becomes a non-leaf subtree
    r = run(workspace, "next", "--role", "planner", check=True)
    child_a_id = parse_frontmatter(r.stdout)[0]["node_id"]
    child_a_dir = _find_node_dir(workspace, child_a_id)
    write(child_a_dir / "verify.md", "grandchildren done")
    run(workspace, "split", child_a_id, "Grandchild 1", "Grandchild 2", check=True)

    # rm Child A without --recursive should fail (has children)
    r = run(workspace, "admin", "rm", child_a_id)
    assert r.returncode == 43
    assert "recursive" in r.stderr.lower()

    # rm Child A with --recursive should delete Child A + both grandchildren
    r = run(workspace, "admin", "rm", child_a_id, "--recursive", check=True)
    assert "Deleted 3" in r.stdout


def test_admin_reparent(workspace: Path):
    """admin reparent changes a node's parent."""
    run(workspace, "init", "root", "--control-plane", "--target", "target", check=True)
    r = run(workspace, "next", "--role", "planner", check=True)
    fm, _ = parse_frontmatter(r.stdout)
    root_id = fm["node_id"]

    root_dir = _find_node_dir(workspace, root_id)
    write(root_dir / "verify.md", "done")
    run(workspace, "split", root_id, "Child A", "Child B", check=True)

    nodes_root = workspace / ".goalie" / "nodes"
    all_dirs = [d for d in nodes_root.iterdir() if d.is_dir() and (d / "goal.md").exists()]
    child_a_dir = next(d for d in all_dirs if "child-a" in d.name)
    child_b_dir = next(d for d in all_dirs if "child-b" in d.name)

    child_a_id = yaml.safe_load(child_a_dir.joinpath("goal.md").read_text().split("---")[1])["id"]
    child_b_id = yaml.safe_load(child_b_dir.joinpath("goal.md").read_text().split("---")[1])["id"]

    # reparent child_a under child_b
    r = run(workspace, "admin", "reparent", child_a_id, child_b_id, check=True)
    assert "reparented" in r.stdout

    # cycle check: reparenting child_b under child_a should fail now
    r = run(workspace, "admin", "reparent", child_b_id, child_a_id)
    assert r.returncode == 43
    assert "cycle" in r.stderr.lower()
