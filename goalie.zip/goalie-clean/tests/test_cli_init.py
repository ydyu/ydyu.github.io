"""Tests for `goalie cli init` re-render (finding N7)."""
from __future__ import annotations

from pathlib import Path

from tests.conftest import run


def _setup_workspace(workspace: Path, vendor: str = "claude") -> None:
    """Init a workspace with the given vendor."""
    run(workspace, "init", "test goal",
        "--control-plane", "--target", "target",
        "--cli", vendor, check=True)


def test_cli_init_rerenders_vendor_files(workspace: Path) -> None:
    """Re-running `goalie cli init <vendor>` overwrites vendor files (idempotent re-render)."""
    target = workspace / "target"
    _setup_workspace(workspace, "claude")

    # Corrupt the file to confirm it gets overwritten
    claude_cmd = target / ".claude" / "commands" / "planner.md"
    assert claude_cmd.exists()
    original = claude_cmd.read_text()
    claude_cmd.write_text("corrupted content")
    assert claude_cmd.read_text() == "corrupted content"

    r = run(workspace, "cli", "init", "claude", check=True)
    assert r.returncode == 0
    assert "Vendor files written" in r.stdout

    # File should be restored (vendor files are always overwritten on cli init)
    assert claude_cmd.read_text() == original


def test_cli_init_force_resets_skills(workspace: Path) -> None:
    """`goalie cli init <vendor> --force` resets skill templates and re-renders vendor files."""
    target = workspace / "target"
    _setup_workspace(workspace, "claude")

    skills_dir = workspace / ".goalie" / "skills"
    base_skill = skills_dir / "_base.md"
    assert base_skill.exists()

    # Corrupt the skill file
    original_skill = base_skill.read_text()
    base_skill.write_text("corrupted skill content")
    assert base_skill.read_text() == "corrupted skill content"

    r = run(workspace, "cli", "init", "claude", "--force", check=True)
    assert r.returncode == 0
    assert "Skills reset" in r.stdout
    assert "Vendor files written" in r.stdout

    # Skill file should be restored
    assert base_skill.read_text() == original_skill


def test_cli_init_without_force_preserves_skills(workspace: Path) -> None:
    """`goalie cli init <vendor>` without --force does not touch skill templates."""
    _setup_workspace(workspace, "claude")

    skills_dir = workspace / ".goalie" / "skills"
    base_skill = skills_dir / "_base.md"
    custom_content = "# My custom skill\nDo stuff.\n"
    base_skill.write_text(custom_content)

    r = run(workspace, "cli", "init", "claude", check=True)
    assert r.returncode == 0
    assert "Skills reset" not in r.stdout

    # Skill file should be unchanged
    assert base_skill.read_text() == custom_content


def test_cli_init_adds_second_vendor(workspace: Path) -> None:
    """Running `goalie cli init <vendor2>` after init with vendor1 adds the second vendor."""
    target = workspace / "target"
    _setup_workspace(workspace, "claude")

    # Gemini files should not exist yet
    assert not (target / ".gemini" / "commands" / "planner.toml").exists()

    r = run(workspace, "cli", "init", "gemini", check=True)
    assert r.returncode == 0
    assert "Vendor files written" in r.stdout

    # Gemini files should now exist
    assert (target / ".gemini" / "commands" / "planner.toml").exists()
    assert (target / ".gemini" / "commands" / "solver.toml").exists()
    assert (target / ".gemini" / "commands" / "reviewer.toml").exists()

    # Claude files should still exist (not removed by adding gemini)
    assert (target / ".claude" / "commands" / "planner.md").exists()

    # Config should record both vendors
    import yaml
    cfg = yaml.safe_load((workspace / ".goalie" / "config.yaml").read_text())
    assert "claude" in cfg["vendors"]
    assert "gemini" in cfg["vendors"]


def test_cli_init_unknown_vendor_errors(workspace: Path) -> None:
    """`goalie cli init <unknown>` returns exit code 43 and mentions known vendors."""
    _setup_workspace(workspace, "claude")

    r = run(workspace, "cli", "init", "unknownvendor")
    assert r.returncode == 43
    assert "unknownvendor" in r.stderr or "unknownvendor" in r.stdout
