"""Regression: the CP path must not appear anywhere in `render_next` output."""
from __future__ import annotations

from pathlib import Path

from tests.conftest import run, parse_frontmatter, write


def test_render_no_cp_path_leak(tmp_path):
    target = tmp_path / "target"
    target.mkdir()
    cp_dir = tmp_path / "control-plane-secret-path"
    cp_dir.mkdir()

    run(
        cp_dir,
        "init", "Root goal for leak test",
        "--control-plane", "--target", str(target),
        check=True,
    )

    cp_goalie = cp_dir / ".goalie"

    r = run(
        target,
        "next", "--role", "planner",
        env={"GOALIE_CP": str(cp_goalie)},
        check=True,
    )

    cp_path_str = str(cp_goalie)
    assert cp_path_str not in r.stdout, (
        f"CP path {cp_path_str!r} leaked into render_next output"
    )
    fm, body = parse_frontmatter(r.stdout)
    for key, val in fm.items():
        assert cp_path_str not in str(val), (
            f"CP path leaked in frontmatter field {key!r}"
        )


def test_render_no_cp_path_leak_in_ancestor_bodies(tmp_path):
    """Ancestor bodies in the Context breadcrumb must not expose the CP path."""
    target = tmp_path / "target"
    target.mkdir()
    cp_dir = tmp_path / "control-plane-secret-path"
    cp_dir.mkdir()

    run(
        cp_dir,
        "init", "Root goal for leak test",
        "--control-plane", "--target", str(target),
        check=True,
    )

    cp_goalie = cp_dir / ".goalie"
    env = {"GOALIE_CP": str(cp_goalie)}

    r = run(target, "next", "--role", "planner", env=env, check=True)
    fm, _ = parse_frontmatter(r.stdout)
    root_id = fm["node_id"]

    # Stage goal+verify, then split (split installs the staging files)
    write(target / f"goalie_goal_{root_id}.md", "Intent: build the thing.")
    write(target / f"goalie_verify_{root_id}.md", "root done")
    run(target, "split", root_id, "Child goal", env=env, check=True)

    r = run(target, "next", "--role", "planner", env=env, check=True)

    cp_path_str = str(cp_goalie)
    assert cp_path_str not in r.stdout, (
        f"CP path leaked into next output (possibly via ancestor body)"
    )
