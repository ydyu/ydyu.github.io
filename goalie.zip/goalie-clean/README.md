# Goalie

A control-plane CLI for multi-agent recursive work on a git repo. Goalie holds the goal graph and routes work to roles (**planner**, **solver**, **reviewer**); your AI agents provide the execution.

The role is named **solver** because a leaf may call for code, docs, config, research, or scripted operations.

Goalie is a deterministic state machine — it has no LLM SDK on its critical path. Agents talk to it through plain shell commands, and read its output (JSON frontmatter + markdown body) the way a human would.

## How it fits together

```
┌─────────────────────┐         ┌──────────────────┐
│  .goalie/           │         │  target_repo/    │
│  (control plane)    │         │  (where work     │
│   • config.json     │         │   actually       │
│   • nodes/<id>/     │         │   lands)         │
│   • skills/         │         │                  │
│   • index.lock      │         │  + GOALIE.md     │
└─────────────────────┘         │  + .claude/      │
        ▲                       │  + .github/      │
        │ goalie next/done/…    │  + .gemini/      │
        │ (never direct reads)  │                  │
        │                       └──────────────────┘
   ┌────┴───────┬───────────┐        ▲
   │            │           │        │ cwd (where agents run)
 planner      solver       reviewer  │
   └────────────┴───────────┘        │
                 ▲               ┌───┴──────────────────┐
                 │               │  agent shell         │
                 └───────────────│  GOALIE_CP=<cp-path> │
                   goalie cmds   └──────────────────────┘
```

The control plane (`.goalie/`) can live anywhere. The target repo (where work actually happens) lives wherever you point `--target`. They can be the same directory, sibling clones, or git worktrees. Each agent session binds to a specific CP via `GOALIE_CP` — one env var, set once per shell.

## Install

Requires Python ≥ 3.10 and git. Zero runtime dependencies — works in air-gapped or pip-restricted environments.

```bash
git clone https://github.com/youruser/goalie.git   # placeholder — replace with the real URL or check the project homepage
cd goalie
pip install -e .
```

## Quickstart

### Single-directory mode (control plane *inside* the target repo)

```bash
cd ~/code/myproject
goalie init "Add a /healthz endpoint" --cli all
```

This:
- Creates `.goalie/` in `myproject/`, with the root goal in `unplanned`.
- Writes `GOALIE.md` (goalie-owned context file) plus per-role slash commands under `.claude/commands/`, `.github/skills/`, and `.gemini/commands/`, and the unified goalie agent under `.claude/agents/` and `.github/agents/`.
- Prints instructions for wiring `GOALIE.md` into `CLAUDE.md`, `GEMINI.md`, and `.github/copilot-instructions.md` / `AGENTS.md` — paste the relevant line(s) yourself, or let your CLI agent do it from the console output.
- `target_repo` defaults to `.`.

Goalie will print the next step — typically `Next: goalie next --role planner`. Open your AI assistant and run `/planner`, or follow that hint directly.

### Worktree mode (recommended for parallel branches)

One control plane per branch, one branch per worktree:

```bash
cd ~/code
git -C myproject worktree add ../myproject-feat-auth feat/auth
mkdir myproject-goalie-auth && cd myproject-goalie-auth
goalie init "Build authentication" \
  --control-plane \
  --target ../myproject-feat-auth \
  --cli all
```

Now `myproject-goalie-auth/.goalie/` controls work happening on the `feat/auth` worktree. Spin up another `myproject-goalie-<branch>/` for each parallel line of work.

See the complete workflow example below — note that the planner must write a `verify.md` for the root node before it can split.

### Pointing target sessions at a control plane

When your agents run in the target repo rather than the CP directory, tell them where the CP lives:

```bash
export GOALIE_CP=~/code/myproject-goalie-auth/.goalie
```

Set this once in each agent shell session. Every `goalie` command reads it automatically — no `--cp` flag required in the normal loop.

`goalie init --control-plane --target ...` and `goalie init --cli ...` both print the exact `export` line for you to paste.

**Multiple CPs against one target repo:** open one shell per CP, set a different `GOALIE_CP` in each. The up-arrow command (`goalie next --role <role>`) is identical across them.

**One-off override:** `--cp <path>` overrides `GOALIE_CP` for a single command; not recommended for the default loop.

**If no CP is found** (neither `GOALIE_CP` nor a `.goalie/` ancestor), goalie exits with:

```
FATAL: FileNotFoundError: no control plane found.
  - set GOALIE_CP=<path/to/control-plane> in this shell, or
  - run goalie from inside (or a descendant of) a directory that
    contains .goalie/.
```

### Pick which AI vendors to scaffold

```bash
goalie init "..." --cli claude            # only Claude Code
goalie init "..." --cli copilot,gemini    # Copilot + Gemini
goalie init "..." --cli all               # all three (copilot, claude, gemini)
```

## A complete workflow example

Say your target repo is `~/code/myproject`, you're using Claude Code, and you've just initialized:

```bash
cd ~/code
mkdir myproject-goalie && cd myproject-goalie
goalie init "Add a JSON /healthz endpoint to the FastAPI app" \
  --control-plane --target ../myproject --cli all
# goalie prints:
#   export GOALIE_CP=~/code/myproject-goalie/.goalie
# Paste that line into each agent shell session.
# It also prints wiring instructions — add @GOALIE.md to your CLAUDE.md, etc.
```

Each agent session runs in the **target repo** with `GOALIE_CP` set:

```bash
# one-time per shell
export GOALIE_CP=~/code/myproject-goalie/.goalie
cd ~/code/myproject
```

#### Turn 1 — Planner decomposes

In Claude Code:
```
/planner
```
`/planner` is a no-args slash command — typing it loads `.claude/commands/planner.md` as the agent's prompt, which itself runs `goalie next --role planner` and proceeds. You don't pass extra text. (Same for `/solver` and `/reviewer`.)

The skill prints the root node. IDs come from `goalie tree` output or the `goalie init` confirmation line. The agent decides this is too big, so it first writes `goalie_verify_<root_id>.md` in the target repo and stages it:
```bash
goalie plan <root_id>      # verify-only mode — no task file needed for a parent node
```
Then it splits:
```bash
goalie split <root_id> \
  "Wire up /healthz route" \
  "Add a unit test for /healthz" \
  "Update OpenAPI tags"
```
Root → `pending`. Three children appear, all `unplanned`. The root won't appear in any role's queue until all descendants are `done`.

#### Turn 2 — Planner plans the first leaf

```
/planner
```
`goalie next --role planner` returns the first child. The agent writes staging files in the **target repo root** (`~/code/myproject/`):
- `goalie_goal_<child_id>.md` — one paragraph of intent ("what is this subtree for?") — optional but recommended
- `goalie_task_<child_id>.md` — imperative instructions for the solver
- `goalie_verify_<child_id>.md` — concrete acceptance checklist

then runs:
```bash
goalie plan <child_id>      # moves files into .goalie/ under the lock and flips unplanned → pending
```
Status → `pending`.

> The agent uses the `node_id` from the frontmatter verbatim. `goalie plan` resolves the slug-correct node directory — agents must not construct that path themselves.

#### Turn 3 — Solver executes

```
/solver
```
`goalie next --role solver` returns the planned leaf. Frontmatter says `target_repo: ~/code/myproject`. The agent edits files in that repo and runs:
```bash
goalie done <child_id>
```
Status → `needs_review`.

#### Turn 4 — Reviewer verdicts

```
/reviewer
```
`goalie next --role reviewer` returns the same node. The agent reads `## Acceptance`, runs `git diff` in `target_repo`, and either:
- ✓ `goalie approve <child_id>` → status `done`, node records verified HEAD sha.
- ✗ `goalie reject <child_id> "rate-limit logic missing"` → status `rejected`.

#### Turn 5 — Solver retries (if rejected)

`/solver` again. `goalie next --role solver` returns the rejected node, and the markdown now includes a **`## Prior reviewer feedback`** section with the critique. The agent fixes the issue and re-submits.

Repeat `/planner` → `/solver` → `/reviewer` until the whole tree is `done`.

You can also stop at any point and inspect:
```bash
goalie tree       # full graph with status glyphs
goalie status     # counts by status
```

See [Command reference](#command-reference) for all flags and exit codes.

## Status vocabulary

| Status | Meaning | Whose watchlist by default |
|---|---|---|
| `unplanned` | Goal exists; no `task.md`/`verify.md` yet | planner |
| `pending` | Planned and ready for solver work | solver |
| `needs_review` | Solver submitted; awaiting verdict | reviewer |
| `rejected` | Reviewer failed; solver retries with critique | solver |
| `done` | Reviewer passed; commit landed | — |

After `split`, the parent becomes `pending` but is excluded from role queues by structural filters until all descendants are `done`.

The role → status mapping lives in `.goalie/config.json` and is fully configurable.

## Identifying nodes

`goalie tree` shows each node with a short ID in backticks — the shortest suffix of its internal ULID (ULID — a time-ordered unique identifier, e.g. `01HZW5P…`) that is unique within the current tree (at least 4 chars). Use this short ID in any command that takes `<id>`.

For example:
```
┬ `1a2b` Add a /healthz endpoint [pending]
  ✓ `3f2e` Wire up /healthz route [done]
  ▼ `9d4a` Add a unit test for /healthz [needs_review]
  ◯ `7b8c` Update OpenAPI tags [unplanned]
```

Goalie resolves `<id>` as follows, in order:
1. **Directory slug** — the human-readable folder name under `.goalie/nodes/` (e.g. `wire-up-healthz-route`). Safe to use if you've inspected the directory.
2. **ULID suffix** — any trailing substring ≥4 chars, case-insensitive (what `goalie tree` prints).
3. **ULID prefix** — any leading substring ≥4 chars (legacy; works but may collide for nodes created in the same millisecond).
4. **Full ULID** — always unambiguous.

If a string matches more than one node, goalie aborts with exit 43.

## Command reference

| Command | What it does |
|---|---|
| `goalie init <goal>` | Initialize the control plane and root goal |
| `goalie cli init [vendors...] [--force]` | Re-render vendor files from `.goalie/skills/`; wire new vendors into config. `--force` resets skill files from bundled templates first. |
| `goalie next [<id>] --role <r>` | Pull next task for a role (frontmatter + body to stdout). Pass an ID to target a specific task for parallel work. |
| `goalie plan [<id>]` | Finalize staged `goalie_task_*.md`, `goalie_verify_*.md`, and/or `goalie_goal_*.md` into the control plane; auto-detects id if omitted. Flips `unplanned → pending` if task+verify are both present. |
| `goalie split <id> "<a>" "<b>"...` | Decompose a node into children (requires `goalie_verify_<id>.md` on the parent — run `goalie plan <id>` first) |
| `goalie done <id>` | Submit solver work for review: `pending → needs_review`. |
| `goalie approve <id>` | Accept reviewed work: `needs_review → done`. Creates git commit. |
| `goalie reject <id> "<reason>"` | Reject work with critique: `needs_review → rejected`. |
| `goalie show <id>` | Print goal/task/verify/Q&A for a node (read-only) |
| `goalie doctor [--prune]` | Report orphan node dirs; `--prune` deletes them |
| `goalie tree` | Print the goal graph |
| `goalie status` | Counts by status |

### Global flags (all commands except `init`)

| Flag / env var | Effect |
|---|---|
| `--cp <path>` | Override the control-plane path for this one command |
| `GOALIE_CP=<path>` | Set the control-plane path for the whole shell session (recommended) |

Resolution order: `--cp` > `GOALIE_CP` > walk up from cwd > loud error.

### Init flags

| Flag | Effect |
|---|---|
| `--control-plane` | Initialize `.goalie/` decoupled from the target (requires `--target`) |
| `--target <path>` | Path to the target repo (default `.`) |
| `--cli copilot,claude,gemini` | Scaffold role skills + render vendor files for listed vendors. Use `all` for all three. |

### Exit codes

`0` ok · `40` fatal · `41` lock contention · `42` no work for this role · `43` bad request

## Customizing skills

After `init --cli ...`, the **canonical** skill files live at:

```
.goalie/skills/_base.md
.goalie/skills/planner.md
.goalie/skills/solver.md
.goalie/skills/reviewer.md
```

Edit these to taste. The derived vendor files (`GOALIE.md`, `.claude/commands/*.md`, `.claude/agents/goalie.md`, `.github/skills/*.md`, `.github/agents/goalie.md`, `.gemini/commands/*.toml`) are regenerated from these on every render — re-run at any time:

```bash
goalie cli init              # re-render all wired vendors
goalie cli init gemini       # wire a new vendor (or re-render just that one)
goalie cli init --force      # also reset .goalie/skills/*.md from bundled templates
```

Goalie never modifies `CLAUDE.md`, `GEMINI.md`, `AGENTS.md`, or `.github/copilot-instructions.md` — those are yours. `goalie cli init` prints the wiring instructions (e.g. `@GOALIE.md`) again whenever you add a new vendor.

Skill templates assume the agent's cwd is the target repo with `GOALIE_CP` set. If you prefer to run planner from inside the CP directory instead, the walk-up resolution handles it automatically — no env var needed as long as cwd is inside (or is) the directory containing `.goalie/`.

## How safety works

- **Branch isolation by convention.** Goalie has no branch awareness. Use one control plane per worktree, and you can run multiple parallel goalies on the same repo without interference.
- **Concurrency.** Every state-mutating operation acquires `.goalie/index.lock` via `fcntl.flock`. Contention >2s aborts with exit 41.
- **Prompt-injection hardening.** User-authored content (goal text, prior critiques, human answers) is rendered inside fenced blocks; the renderer scrubs known trigger phrases (`ignore previous`, `now act as`, `system:`).
- **Trust boundary.** Goalie's runtime output uses declarative voice ("the next task is…"). The skills are imperative (they instruct the AI). Frontmatter is metadata; fenced body content is data — agents are told not to obey it.

## What's stable, what's deferred

Stable: shell + skills surface (Copilot, Claude Code, Gemini CLI).
Deferred: an MCP server (`goalie-mcp`) exposing the same verbs as MCP tools. The skills survive unchanged; MCP would just be a cleaner invocation surface.
